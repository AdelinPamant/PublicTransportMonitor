﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.DataPersistence;

namespace Main.Business.RepositoryImplementations
{
    public class ActiveStationRepository : RepositoryBase, IActiveStationRepository
    {
        public ActiveStationRepository(ApplicationContext applicationContext)
        : base(applicationContext)
        {
        }

        public IEnumerable<ActiveStation> GetActiveStations()
        {
            return ApplicationContext.ActiveStations;
        }
    }
}