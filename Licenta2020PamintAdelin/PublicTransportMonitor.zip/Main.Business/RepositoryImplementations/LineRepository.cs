﻿using System.Collections.Generic;
using System.Linq;
using Extensions;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.Core.ResourceParameters;
using Main.DataPersistence;
using Microsoft.EntityFrameworkCore;

namespace Main.Business.RepositoryImplementations
{
    public class LineRepository : RepositoryBase, ILineRepository
    {
        public LineRepository(ApplicationContext applicationContext)
        : base(applicationContext)
        { }

        public IEnumerable<Line> GetLines()
        {
            return ApplicationContext.Lines
                .Include(l => l.Routes)
                .ThenInclude(r => r.Stations)
                .ToList<Line>();
        }

        public IEnumerable<Line> GetLines(LineResourceParameters lineResourceParameters)
        {
            if (string.IsNullOrEmpty(lineResourceParameters.StartStation) ||
                string.IsNullOrEmpty(lineResourceParameters.DestinationStation))
            {
                return GetLines();
            }

            return GetLines()
                .Where(line => HasStationsInGivenOrder(line, lineResourceParameters))
                .ToList();
        }

        private bool HasStationsInGivenOrder(Line line, LineResourceParameters lineResourceParameters)
        {
            return line.Routes.Any(r => r.HasStationsInGivenOrder(lineResourceParameters));
        }
    }
}
