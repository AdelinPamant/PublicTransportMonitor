﻿using Main.Core.RepositoryInterfaces;
using Main.DataPersistence;

namespace Main.Business.RepositoryImplementations
{
    public class RepositoryBase : IRepositoryBase
    {
        protected readonly ApplicationContext ApplicationContext;

        protected RepositoryBase(ApplicationContext applicationContext)
        {
            ApplicationContext = applicationContext;
        }

        public void SaveChanges()
        {
            ApplicationContext.SaveChanges();
        }
    }
}