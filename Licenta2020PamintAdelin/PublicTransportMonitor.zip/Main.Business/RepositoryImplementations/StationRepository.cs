﻿using System.Collections.Generic;
using Main.Business.Common.Extensions;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.DataPersistence;

namespace Main.Business.RepositoryImplementations
{
    public class StationRepository : RepositoryBase, IStationRepository
    {
        public StationRepository(ApplicationContext applicationContext)
        : base(applicationContext)
        {
        }

        public IEnumerable<Station> GetAllStations()
        {
            return ApplicationContext
                .Stations
                .DistinctByName();
        }
    }
}