﻿using System;
using System.Collections.Generic;
using System.Linq;
using Extensions.Shared;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.Core.ResourceParameters;
using Main.DataPersistence;
using Microsoft.EntityFrameworkCore;

namespace Main.Business.RepositoryImplementations
{
    public class ActiveLineRepository : RepositoryBase, IActiveLineRepository
    {
        public ActiveLineRepository(ApplicationContext applicationContext)
        : base(applicationContext)
        { }
        
        public IEnumerable<ActiveLine> GetActiveLines()
        {
            return ApplicationContext
                .ActiveLines
                .Include(al => al.ActiveStations)
                .ToList();
        }

        public IEnumerable<ActiveLine> GetActiveLines(ActiveLineResourceParameters activeLineResourceParameters)
        {
            if (string.IsNullOrEmpty(activeLineResourceParameters.StartStation) ||
                string.IsNullOrEmpty(activeLineResourceParameters.DestinationStation))
            {
                return GetActiveLines();
            }

            return GetActiveLines()
                .Where(activeLine => HasStationsInGivenOrder(activeLine, activeLineResourceParameters))
                .ToList();
        }

        public void AddActiveLine(ActiveLine activeLine)
        {
            if (activeLine is null)
            {
                throw new ArgumentNullException();
            }

            ApplicationContext.ActiveLines.Add(activeLine);
        }

        public void UpdateActiveLine(ActiveLine activeLine)
        {
            if (activeLine is null)
            {
                throw new ArgumentNullException();
            }

            ApplicationContext.ActiveLines.Update(activeLine);
            //ApplicationContext.Entry(activeLine).State = EntityState.Modified;
        }

        public void DeleteActiveLine(Guid activeLineId)
        {
            var activeLineToDelete = ApplicationContext.ActiveLines.Single(a => a.Id == activeLineId);

            ApplicationContext.ActiveLines.Remove(activeLineToDelete);
        }

        private bool HasStationsInGivenOrder(ActiveLine activeLine, ActiveLineResourceParameters activeLineResourceParameters)
        {
            var stations = activeLine.ActiveStations.Select(s => s.Name).ToList();

            return OrderingChecks.ListHasStationsInGivenOrder(
                stations,
                activeLineResourceParameters);
        }
    }
}
