﻿using System;

namespace Main.Business.Dtos
{
    public class ActiveStationForDisplayDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public bool IsPassed { get; set; }

        public decimal Latitude { get; set; }

        public decimal Longitude { get; set; }

        public ActiveLineForDisplayDto ActiveLine { get; set; }

        public Guid ActiveLineId { get; set; }
    }
}