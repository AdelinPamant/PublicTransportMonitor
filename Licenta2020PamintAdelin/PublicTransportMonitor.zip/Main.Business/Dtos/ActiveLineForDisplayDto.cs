﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;

namespace Main.Business.Dtos
{
    public class ActiveLineForDisplayDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public decimal UserLatitude { get; set; }

        public decimal UserLongitude { get; set; }

        public List<ActiveStation> ActiveStations { get; set; }

        public string NextStation { get; set; }

        public string NextStationStatus { get; set; }

        public long Timestamp { get; set; }

        public string Type { get; set; }
    }
}