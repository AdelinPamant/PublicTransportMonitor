﻿namespace Main.Business.Dtos
{
    public class ActiveLineForInsertDto
    {
        public string Name { get; set; }

        public string StartStation { get; set; }

        public string DestinationStation { get; set; }

        public decimal UserLatitude { get; set; }

        public decimal UserLongitude { get; set; }

        public long Timestamp { get; set; }
    }
}