﻿namespace Main.Business.Dtos
{
    public class ActiveLineForCreationDto : ActiveLineForInsertDto
    {
    }
}
