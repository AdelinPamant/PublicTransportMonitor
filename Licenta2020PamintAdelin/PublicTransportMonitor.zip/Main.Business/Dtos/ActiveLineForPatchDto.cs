﻿namespace Main.Business.Dtos
{
    public class ActiveLineForPatchDto
    {
        public string UserLatitude { get; set; }

        public string UserLongitude { get; set; }
    }
}