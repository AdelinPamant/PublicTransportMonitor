﻿namespace Main.Business.Dtos
{
    public class ActiveLineForUpdateDto : ActiveLineForInsertDto
    {
    }
}
