﻿using System.Reflection.Metadata.Ecma335;

namespace Main.Business.Dtos
{
    public class ActiveStationForUpdateDto
    {
        public bool IsActive { get; set; }

        public bool IsPassed { get; set; }
    }
}