﻿using System.Collections.Generic;
using System.Linq;
using Main.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Main.Business.Common.Extensions
{
    public static class DbSetStationsExtensions
    {
        public static IEnumerable<Station> DistinctByName(this DbSet<Station> stations)
        {
            return stations
                .ToList()
                .GroupBy(s => s.Name)
                .ToList()
                .Select(g => g.First());
        }
    }
}