﻿using System.Linq;
using Extensions.Shared;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Extensions
{
    public static class RouteExtensions
    {
        public static bool HasStationsInGivenOrder(
            this Route route,
            LineBaseResourceParameters activeLineResourceParameters)
        {
            var stations = route.Stations.Select(s => s.Name).ToList();

            return OrderingChecks
                .ListHasStationsInGivenOrder(
                    stations,
                    activeLineResourceParameters);
        }
    }
}
