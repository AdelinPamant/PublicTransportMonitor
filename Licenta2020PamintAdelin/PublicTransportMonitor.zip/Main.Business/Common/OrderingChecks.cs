﻿using System.Collections.Generic;
using System.Linq;
using Main.Core.ResourceParameters;

namespace Extensions.Shared
{
    public static class OrderingChecks
    {
        public static bool ListHasStationsInGivenOrder(
            List<string> stations,
            LineBaseResourceParameters activeLineResourceParameters)
        {
            stations = stations.Select(s => s.FormatForCompare()).ToList();
            var startStation = activeLineResourceParameters.StartStation.FormatForCompare();
            var destinationStation = activeLineResourceParameters.DestinationStation.FormatForCompare();

            if (stations.Contains(startStation) &&
                stations.Contains(destinationStation))
            {
                return stations.IndexOf(startStation) < stations.IndexOf(destinationStation);
            }

            return false;
        }

        private static string FormatForCompare(this string station)
        {
            return station.ToLower().Trim();
        }
    }
}
