﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Extensions;
using Main.Business.BusinessServices;
using Main.Business.Dtos;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Main.Business.Profiles
{
    public class ActiveLineProfiles : Profile
    {
        public ActiveLineProfiles()
        {
            //CreateMap<ActiveLineForCreationDto, ActiveLine>()
            //    .ConvertUsing<ActiveLineForInsertToActiveLine>();

            CreateMap<ActiveLineForInsertDto, ActiveLine>()
                .ConvertUsing<ActiveLineForInsertToActiveLine>();

            CreateMap<ActiveLine, ActiveLineForDisplayDto>()
                .ForMember(
                    dest => dest.NextStationStatus,
                    opt => opt.MapFrom(src => src.NextStationStatus.ToString()));

            CreateMap<ActiveLine, ActiveLineForPatchDto>();

            CreateMap<ActiveLineForPatchDto, ActiveLine>();
        }

        public class ActiveLineForInsertToActiveLine : ITypeConverter<ActiveLineForInsertDto, ActiveLine>
        {
            private readonly ILineService _lineService;

            public ActiveLineForInsertToActiveLine(ILineService lineService)
            {
                _lineService = lineService;
            }
            
            public ActiveLine Convert(ActiveLineForInsertDto source, ActiveLine destination, ResolutionContext context)
            {
                // TODO: move stations creation step in ActiveLineService
                var line = _lineService.GetLineByName(source.Name);
                var activeLineResourceParameter = new ActiveLineResourceParameters{ StartStation = source.StartStation, DestinationStation = source.DestinationStation };
                var stations = line.Routes.First(r =>
                    r.HasStationsInGivenOrder(activeLineResourceParameter)).Stations;

                var activeLine = new ActiveLine
                {
                    Name = line.Name,
                    Type = line.Type,
                    UserLatitude = source.UserLatitude,
                    UserLongitude = source.UserLongitude,
                    Timestamp = source.Timestamp
                    //ActiveStations = context.Mapper.Map<List<ActiveStation>>(
                    //    stations, opt =>
                    //    {
                    //        opt.Items["activeLine"] = line;
                    //        opt.Items["stations"] = stations;
                    //    })
                };

                activeLine.ActiveStations = stations.Select(s =>
                        new ActiveStation
                        {
                            Name = s.Name,
                            Latitude = s.Latitude,
                            Longitude = s.Longitude,
                            IsActive = s.Name == source.StartStation,
                            IsPassed = IsStationBeforeOrEqualToStartStation(s.Name, source.StartStation, stations),
                            //ActiveLine = activeLine,
                            ActiveLineId = activeLine.Id
                        }).ToList();

                return activeLine;
            }

            private bool IsStationBeforeOrEqualToStartStation(string stationName, string startStation, List<Station> stations)
            {
                var stationIndex = stations.IndexOf(stations.First(s => s.Name == stationName));
                var startStationIndex = stations.IndexOf(stations.First(s => s.Name == startStation));

                return stationIndex <= startStationIndex;
            }
        }
    }
}