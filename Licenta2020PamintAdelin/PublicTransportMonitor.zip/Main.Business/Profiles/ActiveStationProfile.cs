﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Main.Business.Dtos;
using Main.Core.Entities;

namespace Main.Business.Profiles
{
    public class ActiveStationProfile : Profile
    {
        public ActiveStationProfile()
        {
            CreateMap<Station, ActiveStation>()
                .ForMember(dest => dest.IsActive,
                    opt => opt.MapFrom<IsActiveStationResolver>())
                .ForMember(dest => dest.IsPassed,
                    opt => opt.MapFrom<IsPassedStationResolver>());

            CreateMap<ActiveStation, ActiveStationForDisplayDto>();
        }

        private class IsActiveStationResolver : IValueResolver<Station, ActiveStation, bool>
        {
            public bool Resolve(Station source, ActiveStation destination, bool destMember, ResolutionContext context)
            {
                return ((ActiveLineForCreationDto) context.Items["activeLine"]).StartStation == source.Name;
            }
        }

        private class IsPassedStationResolver : IValueResolver<Station, ActiveStation, bool>
        {
            public bool Resolve(Station source, ActiveStation destination, bool destMember, ResolutionContext context)
            {
                var stations = (List<Station>) context.Items["stations"];
                var activeLine = (ActiveLineForCreationDto) context.Items["activeLine"];

                var stationIndex = stations.IndexOf(stations.First(s => s.Name == source.Name));
                var startStationIndex = stations.IndexOf(stations.First(s => s.Name == activeLine.StartStation));

                return stationIndex < startStationIndex;
            }
        }
    }
}