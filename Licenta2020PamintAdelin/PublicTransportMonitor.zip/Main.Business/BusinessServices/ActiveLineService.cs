﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Main.Business.Dtos;
using Main.Core.Entities;
using Main.Core.Enums;
using Main.Core.RepositoryInterfaces;
using Main.Core.ResourceParameters;

namespace Main.Business.BusinessServices
{
    public class ActiveLineService : IActiveLineService
    {
        private readonly IActiveLineRepository _activeLineRepository;
        private readonly IActiveStationService _activeStationService;
        private readonly ILocationService _locationService;
        private readonly IMapper _mapper;

        public ActiveLineService(
            IActiveLineRepository activeLineRepository,
            IActiveStationService activeStationService,
            ILocationService locationService,
            IMapper mapper)
        {
            _activeLineRepository = activeLineRepository;
            _activeStationService = activeStationService;
            _locationService = locationService;
            _mapper = mapper;
        }

        public IEnumerable<ActiveLineForDisplayDto> GetActiveLinesForDisplay(ActiveLineResourceParameters activeLineResourceParameters)
        {
            var activeLinesFromRepo = _activeLineRepository.GetActiveLines(activeLineResourceParameters);

            return _mapper.Map<IEnumerable<ActiveLineForDisplayDto>>(activeLinesFromRepo);
        }

        public ActiveLineForDisplayDto GetActiveLineForDisplayById(Guid activeLineId)
        {
            var activeLineFromRepo = GetActiveLineFromRepoById(activeLineId);

            if (activeLineFromRepo is null)
            {
                return null;
            }

            return _mapper.Map<ActiveLineForDisplayDto>(activeLineFromRepo);
        }
        
        public ActiveLine GetActiveLineFromRepoById(Guid activeLineId)
        {
            return _activeLineRepository.GetActiveLines()
                .SingleOrDefault(al => al.Id == activeLineId);
        }

        public Guid CreateActiveLine(ActiveLineForInsertDto activeLineForInsertDto)
        {
            var activeLine = _mapper.Map<ActiveLine>(activeLineForInsertDto);
            activeLine.NextStation = _activeStationService.GetNextStationOf(activeLine).Name;
            activeLine.NextStationStatus = NextStationStatus.InStation;

            _activeLineRepository.AddActiveLine(activeLine);
            _activeLineRepository.SaveChanges();

            return activeLine.Id;
        }

        public ActiveLineForPatchDto GetActiveLineForPatchDtoFrom(ActiveLine activeLineFromRepo)
        {
            return _mapper.Map<ActiveLineForPatchDto>(activeLineFromRepo);
        }

        public ActiveLineForDisplayDto PatchActiveLine(ActiveLineForPatchDto activeLineToPatch, ActiveLine activeLineFromRepo)
        {
            var activeLine = _mapper.Map(activeLineToPatch, activeLineFromRepo);

            if (_locationService.ActiveLineJustLeftStation(activeLine))
            {
                activeLine.NextStationStatus = NextStationStatus.JustLeftStation;
                _activeStationService.GetNextStationOf(activeLine).IsPassed = true;
                activeLine.NextStation = _activeStationService.GetNextStationOf(activeLine).Name;
            }

            if (_locationService.IsActiveLineInStation(activeLine))
            {
                activeLine.NextStationStatus = NextStationStatus.InStation;
                _activeStationService.GetCurrentActiveStationOf(activeLine).IsActive = false;
                var nextStation = _activeStationService.GetNextStationOf(activeLine);
                nextStation.IsPassed = true;
                nextStation.IsActive = true;
                activeLine.NextStation = _activeStationService.GetNextStationOf(activeLine).Name;
            }

            if (_locationService.IsActiveLineWithinNextStationRange(activeLine))
            {
                activeLine.NextStationStatus = NextStationStatus.WithinStationRange;
            }

            if (!_locationService.ActiveLineJustLeftStation(activeLine) &&
                !_locationService.IsActiveLineInStation(activeLine) &&
                !_locationService.IsActiveLineWithinNextStationRange(activeLine))
            {
                activeLine.NextStationStatus = NextStationStatus.Running;
            }

            _activeLineRepository.UpdateActiveLine(activeLine);
            _activeLineRepository.SaveChanges();

            return _mapper.Map<ActiveLineForDisplayDto>(activeLine);
        }

        public void DeleteActiveLine(Guid activeLineId)
        {
            _activeLineRepository.DeleteActiveLine(activeLineId);

            _activeLineRepository.SaveChanges();
        }
    }
}