﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;

namespace Main.Business.BusinessServices
{
    public interface IStationService
    {
        IEnumerable<Station> GetStations();
        IEnumerable<Station> GetAllStationsForActiveLineId(Guid activeLineId);
    }
}