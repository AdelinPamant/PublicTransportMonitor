﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;

namespace Main.Business.BusinessServices
{
    public interface IActiveStationService
    {
        IEnumerable<ActiveStation> GetActiveStationsForActiveLineId(Guid activeLineId);
        void UpdateActiveStations(IEnumerable<ActiveStation> activeStations, decimal startStation, decimal destinationStation);
        ActiveStation GetCurrentActiveStationOf(ActiveLine activeLine);
        ActiveStation GetNextStationOf(ActiveLine activeLine);
        ActiveStation GetLastPassedStationOf(ActiveLine activeLine);
    }
}