﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Main.Business.BusinessServices
{
    public interface ILineService
    {
        IEnumerable<Line> GetLines();
        IEnumerable<Line> GetLines(LineResourceParameters lineResourceParameters);
        Line GetLineById(Guid lineId);
        Line GetLineByName(string lineName);
    }
}