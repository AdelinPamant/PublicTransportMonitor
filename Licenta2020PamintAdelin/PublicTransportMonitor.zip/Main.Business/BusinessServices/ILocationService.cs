﻿using Main.Core.Entities;

namespace Main.Business.BusinessServices
{
    public interface ILocationService
    {
        bool ActiveLineJustLeftStation(ActiveLine activeLine);
        bool IsActiveLineWithinNextStationRange(ActiveLine activeLine);
        bool IsActiveLineInStation(ActiveLine activeLine);
    }
}