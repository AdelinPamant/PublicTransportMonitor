﻿using System;
using System.Collections.Generic;
using System.Linq;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;

namespace Main.Business.BusinessServices
{
    public class ActiveStationService : IActiveStationService
    {
        private readonly IActiveStationRepository _activeStationRepository;

        public ActiveStationService(IActiveStationRepository activeStationRepository)
        {
            _activeStationRepository = activeStationRepository;
        }

        public void UpdateActiveStations(IEnumerable<ActiveStation> activeStations, decimal latitude, decimal longitude)
        {
            var closestStation = GetClosestStationToCoordinates(activeStations, latitude, longitude);

            if (!closestStation.IsActive)
            {
                
            }
        }

        public IEnumerable<ActiveStation> GetActiveStationsForActiveLineId(Guid activeLineId)
        {
            return _activeStationRepository
                .GetActiveStations()
                .Where(activeStation => activeStation.ActiveLineId == activeLineId);
        }

        public ActiveStation GetCurrentActiveStationOf(ActiveLine activeLine)
        {
            return activeLine.ActiveStations.First(a => a.IsActive);
        }

        public ActiveStation GetNextStationOf(ActiveLine activeLine)
        {
            return activeLine.ActiveStations.First(s => s.IsPassed == false);
        }

        public ActiveStation GetLastPassedStationOf(ActiveLine activeLine)
        {
            return activeLine.ActiveStations.Last(s => s.IsPassed);
        }

        private ActiveStation GetClosestStationToCoordinates(
            IEnumerable<ActiveStation> activeStations,
            decimal latitude,
            decimal longitude)
        {
            var minDistance = decimal.MaxValue;
            var closestStation = new ActiveStation();

            foreach (var activeStation in activeStations)
            {
                var currentDistance =
                    HaversineDistanceInKm(activeStation.Latitude, activeStation.Longitude, latitude, longitude);
                if (currentDistance < minDistance)
                {
                    minDistance = currentDistance;
                    closestStation = activeStation;
                }
            }

            return closestStation;
        }

        private decimal HaversineDistanceInKm(decimal currentLatitude, decimal currentLongitude, decimal latitude, decimal longitude)
        {
            double r = 6371;
            var lat = (double)(latitude - currentLatitude) * (Math.PI * 180);
            var lng = (double)(longitude - currentLongitude) * (Math.PI * 180);
            var h1 = Math.Sin(lat / 2) * Math.Sin(lat / 2) +
                     Math.Cos((double) currentLatitude * (Math.PI * 180)) *
                     Math.Cos((double) latitude * (Math.PI * 180)) *
                     Math.Sin(lng / 2) * Math.Sin(lng / 2);
            var h2 = 2 * Math.Asin(Math.Min(1, Math.Sqrt(h1)));

            return (decimal)(r * h2);
        }
    }
}