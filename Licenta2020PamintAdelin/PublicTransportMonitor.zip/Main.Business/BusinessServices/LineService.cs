﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.Core.ResourceParameters;

namespace Main.Business.BusinessServices
{
    public class LineService : ILineService
    {
        private readonly ILineRepository _lineRepository;
        private readonly IMapper _mapper;

        public LineService(
            ILineRepository lineRepository,
            IMapper mapper)
        {
            _lineRepository = lineRepository;
            _mapper = mapper;
        }

        public IEnumerable<Line> GetLines()
        {
            // TODO: mappings
            return _lineRepository.GetLines();
        }

        public IEnumerable<Line> GetLines(LineResourceParameters lineResourceParameters)
        {
            // TODO: mappings
            return _lineRepository.GetLines(lineResourceParameters);
        }

        public Line GetLineById(Guid lineId)
        {
            return _lineRepository.GetLines().SingleOrDefault(l => l.Id == lineId);
        }

        public Line GetLineByName(string lineName)
        {
            return _lineRepository.GetLines().SingleOrDefault(l => l.Name == lineName);
        }
    }
}