﻿using System;
using System.Collections.Generic;
using Main.Business.Dtos;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Main.Business.BusinessServices
{
    public interface IActiveLineService
    {
        ActiveLineForDisplayDto GetActiveLineForDisplayById(Guid activeLineId);
        ActiveLine GetActiveLineFromRepoById(Guid activeLineId);
        IEnumerable<ActiveLineForDisplayDto> GetActiveLinesForDisplay(ActiveLineResourceParameters activeLineResourceParameters);
        Guid CreateActiveLine(ActiveLineForInsertDto activeLineDto);
        ActiveLineForPatchDto GetActiveLineForPatchDtoFrom(ActiveLine activeLineFromRepo);
        ActiveLineForDisplayDto PatchActiveLine(ActiveLineForPatchDto activeLineToPatch, ActiveLine activeLineFromRepo);
        void DeleteActiveLine(Guid activeLineId);
    }
}