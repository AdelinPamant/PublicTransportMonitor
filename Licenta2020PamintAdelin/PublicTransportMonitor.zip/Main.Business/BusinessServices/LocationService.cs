﻿using System;
using Main.Business.StaticData;
using Main.Core.Entities;

namespace Main.Business.BusinessServices
{
    public class LocationService : ILocationService
    {
        private readonly IActiveStationService _activeStationService;

        public LocationService(IActiveStationService activeStationService)
        {
            _activeStationService = activeStationService;
        }

        public bool ActiveLineJustLeftStation(ActiveLine activeLine)
        {
            var lastPassedStation = _activeStationService.GetLastPassedStationOf(activeLine);

            return IsActiveLineInStationProximity(activeLine, lastPassedStation);
        }

        public bool IsActiveLineWithinNextStationRange(ActiveLine activeLine)
        {
            var nextStation = _activeStationService.GetNextStationOf(activeLine);

            return IsActiveLineInStationProximity(activeLine, nextStation);
        }

        public bool IsActiveLineInStation(ActiveLine activeLine)
        {
            var nextStation = _activeStationService.GetNextStationOf(activeLine);

            return IsActiveLineInStation(activeLine, nextStation);
        }

        // TODO: maybe these methods should be the contract of LocationService and the above should be in ActiveLineService
        private bool IsActiveLineInStationProximity(ActiveLine activeLine, ActiveStation activeStation)
        {
            var distance = HaversineDistanceInKm(
                activeLine.UserLatitude, activeLine.UserLongitude,
                activeStation.Latitude, activeStation.Longitude);

            return distance <= DistancesInKm.StationProximity;
        }

        private bool IsActiveLineInStation(ActiveLine activeLine, ActiveStation activeStation)
        {
            var distance = HaversineDistanceInKm(
                activeLine.UserLatitude, activeLine.UserLongitude,
                activeStation.Latitude, activeStation.Longitude);

            return distance <= DistancesInKm.InStation;
        }

        private decimal HaversineDistanceInKm(decimal currentLatitude, decimal currentLongitude, decimal latitude, decimal longitude)
        {
            double radiusInKm = 6371;
            var lat = (double)(latitude - currentLatitude) * (Math.PI * 180);
            var lng = (double)(longitude - currentLongitude) * (Math.PI * 180);
            var h1 = Math.Sin(lat / 2) * Math.Sin(lat / 2) +
                     Math.Cos((double)currentLatitude * (Math.PI * 180)) *
                     Math.Cos((double)latitude * (Math.PI * 180)) *
                     Math.Sin(lng / 2) * Math.Sin(lng / 2);
            var h2 = 2 * Math.Asin(Math.Min(1, Math.Sqrt(h1)));

            return (decimal)(radiusInKm * h2);
        }
    }
}