﻿using System;
using System.Collections.Generic;
using System.Linq;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;

namespace Main.Business.BusinessServices
{
    public class StationService : IStationService
    {
        private readonly IStationRepository _stationRepository;

        public StationService(IStationRepository stationRepository)
        {
            _stationRepository = stationRepository;
        }

        public IEnumerable<Station> GetStations()
        {
            return _stationRepository.GetAllStations();
        }

        public IEnumerable<Station> GetAllStationsForActiveLineId(Guid activeLineId)
        {
            return
                _stationRepository
                    .GetAllStations()
                    .Where(station => station.Route.LineId == activeLineId);
        }
    }
}