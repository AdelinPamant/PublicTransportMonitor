﻿using System;
using AutoMapper;
using Main.Business.BusinessServices;
using Main.Business.RepositoryImplementations;
using Main.Core.RepositoryInterfaces;
using Microsoft.Extensions.DependencyInjection;

namespace Main.Business.Configurations
{
    public static class ServiceCollectionExtensions
    {
        public static void AddBusinessLogic(this IServiceCollection services)
        {
            services.AddScoped<IActiveLineRepository, ActiveLineRepository>();
            services.AddScoped<IActiveLineService, ActiveLineService>();

            services.AddScoped<IActiveStationRepository, ActiveStationRepository>();
            services.AddScoped<IActiveStationService, ActiveStationService>();

            services.AddScoped<ILocationService, LocationService>();

            services.AddScoped<ILineRepository, LineRepository>();
            services.AddScoped<ILineService, LineService>();

            services.AddScoped<IStationRepository, StationRepository>();
            services.AddScoped<IStationService, StationService>();

            services.AddScoped<IStationRepository, StationRepository>();

            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }
    }
}