﻿namespace Main.Business.StaticData
{
    public static class DistancesInKm
    {
        public static decimal StationProximity => 0.15m;
        public static decimal InStation => 0.05m;
    }
}