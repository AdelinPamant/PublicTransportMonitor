﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Import.Contracts;
using Newtonsoft.Json;
using RestSharp;

namespace Import.Business
{
    public class CtpRoutesDataAccess
    {
        private readonly RestClient _restClient = new RestClient("https://m-go-iasi.wink.ro/apiPublic/route/byId");

        public List<CtpRoute> GetCtpRoutes()
        {
            var htmlString = GetHtml("https://www.sctpiasi.ro/trasee");
            var routesIds = GetRoutesIds(htmlString);
            var missingRoutesIds = new List<string>{ "57", "48", "63", "54", "62" };

            var ctpRoutes = new List<CtpRoute>();

            ctpRoutes.AddRange(GetCtpRoutesByIds(routesIds));
            ctpRoutes.AddRange(GetCtpRoutesByIds(missingRoutesIds));

            return ctpRoutes;
        }

        private IEnumerable<CtpRoute> GetCtpRoutesByIds(IEnumerable<string> routesIds)
        {
            return routesIds
                .Select(r => JsonConvert.DeserializeObject<CtpRoute>(GetStringResponse(r)))
                .Where(r => r.Data.RouteName != null);
        }

        private string GetStringResponse(string endpoint)
        {
            var request = new RestRequest(endpoint, Method.GET);
            request.AddHeader("Accept", "application/json");

            var responseContent = _restClient.Execute(request).Content;

            return responseContent;
        }

        private List<string> GetRoutesIds(string htmlString)
        {
            var htmlRoutesIds = new Regex(@"trasee\/([0-9][0-9]?)\/").Matches(htmlString);

            var routesIds = htmlRoutesIds.Select(r => r.Value.Split('/')[1]).ToList();

            return routesIds;
        }

        private string GetHtml(string urlAddress)
        {
            var data = "";
            var request = (HttpWebRequest)WebRequest.Create(urlAddress);

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var receivedStream = response.GetResponseStream();
                    using (StreamReader readStream = string.IsNullOrWhiteSpace(response.CharacterSet)
                                                    ? new StreamReader(receivedStream)
                                                    : new StreamReader(receivedStream, Encoding.GetEncoding(response.CharacterSet)))
                    {
                        data = readStream.ReadToEnd();
                    }
                }
            }

            return data;
        }
    }
}
