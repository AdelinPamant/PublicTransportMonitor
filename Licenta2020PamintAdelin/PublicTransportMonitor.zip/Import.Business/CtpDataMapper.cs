﻿using System.Collections.Generic;
using System.Linq;
using Import.Contracts;
using Main.Core.Entities;

namespace Import.Business
{
    public static class CtpDataMapper
    {
        public static List<Line> MapCtpRoutesToLines(this List<CtpRoute> ctpRoutes)
        {
            return ctpRoutes.Select(cr => cr.Data).Select(ctpLine => 
                new Line
                {
                    Name = ctpLine.RouteShortName,
                    Color = ctpLine.RouteColor,
                    Routes = new List<Route>
                    {
                        Route.CreateStartToFinishRoute(ctpLine.RouteWaypoints.MapCtpStationsToStations()),
                        Route.CreateFinishToStartRoute(ctpLine.RouteRoundWaypoints.MapCtpStationsToStations())
                    },
                    StartToFinishLength = int.Parse(ctpLine.RouteWayLength),
                    FinishToStartLength = int.Parse(ctpLine.RouteRoundWayLength)
                }).ToList();
        }

        private static List<Station> MapCtpStationsToStations(this List<CtpStation> ctpStations)
        {
            return ctpStations.Select(cs =>
                new Station
                {
                    Name = cs.Name,
                    Latitude = cs.Lat,
                    Longitude = cs.Lng
                })
                .Where(s => s.Name != "")
                .ToList();
        }
    }
}
