﻿using Main.Core.Entities;
using Main.Core.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Main.DataPersistence
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options)
        : base(options)
        {
        }

        public DbSet<Line> Lines { get; set; }

        public DbSet<Route> Routes { get; set; }

        public DbSet<Station> Stations { get; set; }

        public DbSet<ActiveLine> ActiveLines { get; set; }

        public DbSet<ActiveStation> ActiveStations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var converter = new EnumToStringConverter<NextStationStatus>();
            modelBuilder
                .Entity<ActiveLine>()
                .Property(al => al.NextStationStatus)
                .HasConversion<string>();
        }
    }
}
