﻿namespace Main.DataPersistence.ValueConverters
{
    public class EnumToStringWithSpacesConverter
    {
        
    }
}