﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Main.DataPersistence.Migrations
{
    public partial class AddedTimestampFieldInActiveLine : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Color",
                table: "ActiveLines");

            migrationBuilder.AddColumn<long>(
                name: "Timestamp",
                table: "ActiveLines",
                nullable: false,
                defaultValue: 0L);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Timestamp",
                table: "ActiveLines");

            migrationBuilder.AddColumn<string>(
                name: "Color",
                table: "ActiveLines",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
