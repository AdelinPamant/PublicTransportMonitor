﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Main.DataPersistence.Migrations
{
    public partial class AddedUserLongitudeAndLatitudeToActiveLine : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "UserLatitude",
                table: "ActiveLines",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "UserLongitude",
                table: "ActiveLines",
                nullable: false,
                defaultValue: 0m);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserLatitude",
                table: "ActiveLines");

            migrationBuilder.DropColumn(
                name: "UserLongitude",
                table: "ActiveLines");
        }
    }
}
