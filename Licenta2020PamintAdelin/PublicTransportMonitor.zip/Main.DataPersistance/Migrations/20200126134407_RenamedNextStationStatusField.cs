﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Main.DataPersistence.Migrations
{
    public partial class RenamedNextStationStatusField : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
