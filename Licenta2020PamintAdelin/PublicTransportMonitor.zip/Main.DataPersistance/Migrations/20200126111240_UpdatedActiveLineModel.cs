﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Main.DataPersistence.Migrations
{
    public partial class UpdatedActiveLineModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "NextStation",
                table: "ActiveLines",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NextStationStatus",
                table: "ActiveLines",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NextStation",
                table: "ActiveLines");

            migrationBuilder.DropColumn(
                name: "NextStationStatus",
                table: "ActiveLines");
        }
    }
}
