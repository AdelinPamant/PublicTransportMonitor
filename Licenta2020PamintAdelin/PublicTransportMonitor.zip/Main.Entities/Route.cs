﻿using System;
using System.Collections.Generic;

namespace Main.Entities
{
    public class Route
    {
        public Route()
        {
            Stations = new List<Station>();
        }

        public Guid Id { get; set; }

        public string Type { get; set; }

        public List<Station> Stations { get; set; }

        public Line Line { get; set; }

        public Guid LineId { get; set; }
    }
}
