﻿using System;
using System.Collections.Generic;

namespace Main.Entities
{
    public class ActiveLine
    {
        public ActiveLine()
        {
            ActiveStations = new List<ActiveStation>();
        }

        public Guid Id { get; set; }

        public string Name { get; set; }

        public List<ActiveStation> ActiveStations { get; set; }

        public string Type { get; set; }

        public string Color { get; set; }
    }
}
