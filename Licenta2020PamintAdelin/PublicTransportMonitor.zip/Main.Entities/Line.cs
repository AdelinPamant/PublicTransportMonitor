﻿using System;
using System.Collections.Generic;

namespace Main.Entities
{
    public class Line
    {
        public Line()
        {
            Routes = new List<Route>();
        }

        public Guid Id { get; set; }

        public string Name { get; set; }

        //TODO: make it shadow property both here and in ActiveLine
        public string Type { get; set; }

        public string Color { get; set; }

        public List<Route> Routes { get; set; }

        public int StartToFinishLength { get; set; }

        public int FinishToStartLength { get; set; }
    }
}
