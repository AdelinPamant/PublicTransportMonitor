﻿using System;

namespace Main.Entities
{
    public class RouteStation
    {
        public Guid RouteId { get; set; }

        public Route Route { get; set; }

        public Guid StationId { get; set; }

        public Station Station { get; set; }
    }
}
