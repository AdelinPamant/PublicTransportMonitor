﻿using Import.Business;
using Main.DataPersistence;

namespace Import.ConsoleApp
{
    public class ImportService
    {
        private readonly CtpRoutesDataAccess _ctpRoutesDataAccess;
        private readonly ApplicationContext _applicationContext;

        public ImportService(
            CtpRoutesDataAccess ctpRoutesDataAccess,
            ApplicationContext applicationContext)
        {
            _ctpRoutesDataAccess = ctpRoutesDataAccess;
            _applicationContext = applicationContext;
        }

        public void Import()
        {
            var data = _ctpRoutesDataAccess.GetCtpRoutes();
            var lines = data.MapCtpRoutesToLines();

            _applicationContext.AddRange(lines);
            _applicationContext.SaveChanges();
        }
    }
}