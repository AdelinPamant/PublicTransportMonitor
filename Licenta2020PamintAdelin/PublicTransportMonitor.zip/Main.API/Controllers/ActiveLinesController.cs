﻿using System;
using Main.Business.BusinessServices;
using Main.Business.Dtos;
using Main.Core.ResourceParameters;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Main.API.Controllers
{
    [ApiController]
    [Route("api/activeLines")]
    public class ActiveLinesController : ControllerBase
    {
        private readonly IActiveLineService _activeLineService;

        public ActiveLinesController(
            IActiveLineService activeLineService)
        {
            _activeLineService = activeLineService;
        }

        [HttpGet()]
        public OkObjectResult GetActiveLines(
            [FromQuery] ActiveLineResourceParameters activeLineResourceParameters)
        {
            var activeLinesForDisplay = _activeLineService.GetActiveLinesForDisplay(activeLineResourceParameters);
            
            return Ok(activeLinesForDisplay);
        }
        
        [HttpGet("{activeLineId}", Name = "GetActiveLineById")]
        public ActionResult<ActiveLineForDisplayDto> GetActiveLineById(Guid activeLineId)
        {
            var activeLineForDisplay = _activeLineService.GetActiveLineForDisplayById(activeLineId);

            if (activeLineForDisplay is null)
            {
                return NotFound();
            }

            return Ok(activeLineForDisplay);
        }        

        [HttpPost()]
        public CreatedAtRouteResult CreateActiveLine(ActiveLineForCreationDto activeLineDto)
        {
            var createdActiveLineId = _activeLineService.CreateActiveLine(activeLineDto);
            var createdActiveLine = _activeLineService.GetActiveLineForDisplayById(createdActiveLineId);

            return CreatedAtRoute(
                nameof(GetActiveLineById),
                new { activeLineId = createdActiveLineId },
                createdActiveLine);
        }

        [HttpPatch("{activeLineId}")]
        public IActionResult PartiallyUpdateActiveLine(
            Guid activeLineId,
            JsonPatchDocument<ActiveLineForPatchDto> patchDocument)
        {
            var activeLineFromRepo = _activeLineService.GetActiveLineFromRepoById(activeLineId);

            if (activeLineFromRepo is null)
            {
                return NotFound();
            }

            var activeLineToPatch = _activeLineService.GetActiveLineForPatchDtoFrom(activeLineFromRepo);

            patchDocument.ApplyTo(activeLineToPatch, ModelState);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            // TODO: create a location service that uses active line and station repos and inject the location service
            // in active line service to update all ActiveLine data
            // Also create Position class to send lat lng without order confusion in params
            var patchedLine = _activeLineService.PatchActiveLine(activeLineToPatch, activeLineFromRepo);

            return Ok(patchedLine);

        }

        [HttpDelete("{activeLineId}")]
        public IActionResult DeleteActiveLineById(Guid activeLineId)
        {
            var activeLineToDelete = _activeLineService.GetActiveLineForDisplayById(activeLineId);
            if (activeLineToDelete is null)
            {
                return NotFound();
            }

            _activeLineService.DeleteActiveLine(activeLineId);

            return NoContent();
        }
    }
}
