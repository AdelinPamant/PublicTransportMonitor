﻿using System;
using Main.Business.BusinessServices;
using Microsoft.AspNetCore.Mvc;

namespace Main.API.Controllers
{
    [ApiController]
    [Route("api/activeStations")]
    public class ActiveStationsController : ControllerBase
    {
        private readonly IActiveStationService _activeStationService;

        public ActiveStationsController(IActiveStationService activeStationService)
        {
            _activeStationService = activeStationService;
        }

        [HttpGet("{activeLineId}")]
        public OkObjectResult GetActiveStationsForActiveLineId(Guid activeLineId)
        {
            return Ok(_activeStationService.GetActiveStationsForActiveLineId(activeLineId));
        }
    }
}