﻿using System;
using System.Collections.Generic;
using System.Linq;
using Main.Business.BusinessServices;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace Main.API.Controllers
{
    [ApiController]
    [Route("api/stations")]
    public class StationsController : ControllerBase
    {
        private readonly IStationService _stationService;

        public StationsController(IStationService stationService)
        {
            _stationService = stationService;
        }

        [HttpGet()]
        public OkObjectResult GetAllStations()
        {
            return Ok(_stationService.GetStations());
        }

        [HttpGet("{activeLineId}")]
        public OkObjectResult GetAllStationsForActiveLineId(Guid activeLineId)
        {
            return Ok(_stationService.GetAllStationsForActiveLineId(activeLineId));
        }
    }
}
