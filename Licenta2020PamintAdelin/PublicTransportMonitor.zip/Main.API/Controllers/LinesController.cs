﻿using System;
using System.Collections.Generic;
using Main.Business.BusinessServices;
using Main.Core.Entities;
using Main.Core.RepositoryInterfaces;
using Main.Core.ResourceParameters;
using Microsoft.AspNetCore.Mvc;

namespace Main.API.Controllers
{
    [ApiController]
    [Route("api/lines")]
    public class LinesController : ControllerBase
    {
        private readonly ILineService _lineService;

        public LinesController(ILineService lineService)
        {
            _lineService = lineService;
        }

        [HttpGet()]
        public ActionResult<IEnumerable<Line>> GetLines(
            [FromQuery] LineResourceParameters lineResourceParameters)
        {
            var linesFromRepo = _lineService.GetLines(lineResourceParameters);

            return Ok(linesFromRepo);
        }

        [HttpGet("{lineId}")]
        public ActionResult<Line> GetLineById(Guid lineId)
        {
            var lineFromRepo = _lineService.GetLineById(lineId);

            if (lineFromRepo is null)
            {
                return NotFound();
            }

            return Ok(lineFromRepo);
        }
    }
}