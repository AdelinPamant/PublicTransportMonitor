export const environment = {
  production: false,
  api: 'https://localhost:44311/api/'
};
