import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { AgmCoreModule } from '@agm/core';

import { AppComponent } from './app.component';
import { RegisterActiveLineComponent } from './register-active-line/register-active-line.component';
import { SearchActiveLinesComponent } from './search-active-lines/search-active-lines.component';
import { ListLineItemComponent } from './shared/components/list-line-item/list-line-item.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActiveLineDetailsComponent } from './shared/components/active-line-details/active-line-details.component';
import { MapViewComponent } from './map-view/map-view.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterActiveLineComponent,
    SearchActiveLinesComponent,
    ListLineItemComponent,
    ActiveLineDetailsComponent,
    MapViewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatTabsModule,
    MatAutocompleteModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyC26TufaCJvdSVdD6W4yikCda8kdARQGss'
    }),
    RouterModule.forRoot([
      { path: '', redirectTo: 'search-active-line', pathMatch: 'full' },
      { path: 'map-view', component: MapViewComponent },
      { path: 'register-active-line', component: RegisterActiveLineComponent },
      { path: 'search-active-line', component: SearchActiveLinesComponent },
      { path: 'active-line-details/:id', component: ActiveLineDetailsComponent },
      { path: '**', redirectTo: 'search-lines', pathMatch: 'full' }
    ]),
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
