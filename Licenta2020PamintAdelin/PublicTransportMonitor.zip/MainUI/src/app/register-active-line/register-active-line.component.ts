import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Subscription, combineLatest } from 'rxjs';
import { HttpResponse } from '@angular/common/http';

import { LocationService } from '../shared/services';
import { ActiveLineService, StationService, LineService } from '../api/services';
import { ActiveLineForCreation, ActiveLineForPatch, ActiveLine, Station, Line } from '../api/models';
import { MockLocationService } from '../shared/services/mock-location.service';

@Component({
  selector: 'app-register-active-line',
  templateUrl: './register-active-line.component.html',
  styleUrls: ['./register-active-line.component.scss']
})
export class RegisterActiveLineComponent implements OnInit {

  protected startFilteredStations: string[]
  protected destinationFilteredStations: string[];
  protected filteredLines: string[];
  protected registeredLineId: string;
  private _registeredLineUri = '';
  private _lineForm: FormGroup;
  private _subscription: Subscription;

  constructor(
    private readonly _fb: FormBuilder,
    private readonly _activeLineService: ActiveLineService,
    private readonly _stationService: StationService,
    private readonly _lineService: LineService,
    private readonly _locationService: LocationService,
    private readonly _mockLocationService: MockLocationService
  ) { }

  public ngOnInit(): void {
    this._lineForm = this._fb.group({
      startStation: [''],
      destinationStation: [''],
      lineName: [''],
      userLatitude: [0],
      userLongitude: [0]
    });

    this.handleFieldsAutocomplete();
  }

  protected submit(): void {
    // this.handleMockRegister();
    this.handleLineRegister();
  }

  private handleMockRegister(): void {
    this._mockLocationService.mockLocation$.subscribe((position: Position) => {
      let activeLineForCreation = this.buildActiveLine(position);
      let activeLineForPatch = this.buildActiveLineForPatch(position);

      this._subscription = this._activeLineService.getActiveLineObservableByUri(
        this._registeredLineUri,
        activeLineForCreation,
        activeLineForPatch
      )
      .subscribe((response: HttpResponse<ActiveLineForCreation> | ActiveLine) => {
        // null check because PATCH returns NoContent() and thus, null ?
        if (response !== null &&
            'headers' in response) {
          this._registeredLineUri = response.headers.get('location');
          this.registeredLineId = this._registeredLineUri.split('/').pop();
          this._subscription.unsubscribe();
        } else if ('id' in response) {
          this._activeLineService.alertActiveLineUpdate();

          if (this.activeLineReachedDestination(response)) {
            this._activeLineService.deleteActiveLineById(response.id).subscribe();
            this._activeLineService.alertActiveLineUpdate();
          }
        }
      });
    });
  }

  private handleLineRegister(): void {
    this._locationService.startTracking((position: Position) => {
      let activeLineForCreation = this.buildActiveLine(position);
      let activeLineForPatch = this.buildActiveLineForPatch(position);

      this._subscription = this._activeLineService.getActiveLineObservableByUri(
        this._registeredLineUri,
        activeLineForCreation,
        activeLineForPatch
      )
      .subscribe((response: HttpResponse<ActiveLineForCreation> | ActiveLine) => {
        // null check because PATCH returns NoContent() and thus, null ?
        if (response !== null &&
            'headers' in response) {
          this._registeredLineUri = response.headers.get('location');
          this.registeredLineId = this._registeredLineUri.split('/').pop();
          this._subscription.unsubscribe();
        }
      });
    });
  }

  private buildActiveLine(position: Position): ActiveLineForCreation {
    return {
      name: this._lineForm.get('lineName').value,
      startStation: this._lineForm.get('startStation').value,
      destinationStation: this._lineForm.get('destinationStation').value,
      userLatitude: position.coords.latitude,
      userLongitude: position.coords.longitude,
      timestamp: position.timestamp
    };
  }

  private buildActiveLineForPatch(position: Position): ActiveLineForPatch {
    return {
      userLatitude: position.coords.latitude,
      userLongitude: position.coords.longitude,
      timestamp: position.timestamp
    }
  }

  private handleFieldsAutocomplete(): void {
    combineLatest([
      this._stationService.getStations(),
      this._lineService.getLines(),
      this._lineForm.valueChanges
    ])
    .subscribe(
      ([stations, lines, formData]) => {
        this.startFilteredStations = this.filter(formData.startStation, stations),
        this.destinationFilteredStations = this.filter(formData.destinationStation, stations)
        this.filteredLines = this.filter(formData.lineName, lines)
      }
    );
  }

  private activeLineReachedDestination(activeLine: ActiveLine): boolean {
    let currentStation = activeLine.activeStations.find(s => s.isActive).name;
    return currentStation === this._lineForm.get('destinationStation').value;
  }

  private filter(value: string, stations: Station[] | Line[]): string[] {
    const filterValue = value.toLocaleLowerCase();

    return stations.filter(station => station.name.toLocaleLowerCase().includes(filterValue)).map(station => station.name);
  }
}
 