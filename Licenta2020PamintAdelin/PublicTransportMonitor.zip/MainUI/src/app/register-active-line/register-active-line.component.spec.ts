import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterActiveLineComponent } from './register-active-line.component';

describe('RegisterActiveLineComponent', () => {
  let component: RegisterActiveLineComponent;
  let fixture: ComponentFixture<RegisterActiveLineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterActiveLineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterActiveLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
