import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { combineLatest } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

import { ActiveLineService, ActiveStationService } from 'src/app/api/services';
import { ActiveLine, ActiveStation, Station } from 'src/app/api/models';
import { MockLocationService } from '../../services/mock-location.service';

@Component({
  selector: 'app-active-line-details',
  templateUrl: './active-line-details.component.html',
  styleUrls: ['./active-line-details.component.scss']
})
export class ActiveLineDetailsComponent implements OnInit {

  @Input() activeLineId: string;
  protected tripEnded: boolean = false;
  protected activeLine: ActiveLine;
  protected activeStations: ActiveStation[] = [];
  protected activeStationsToDisplay: ActiveStation[] = [];

  constructor(
    private readonly _activeLineService: ActiveLineService,
    private readonly _activeStationService: ActiveStationService,
    private readonly _mockLocationService: MockLocationService,
    private readonly _router: Router,
    private readonly _route: ActivatedRoute) { }

  ngOnInit() {
    if (!this.isComponentDisplayedForRegisterActiveLine()) {
      this.activeLineId = this._route.snapshot.paramMap.get('id');
    }

    if (isNaN(+this.activeLineId)) {

      this.updateActiveLineData();

      let sub = this._activeLineService.refreshDataFromFunc(() => {
        this._activeLineService.getActiveLineById(this.activeLineId)
          .subscribe(
            (activeLine: ActiveLine) => {
              console.log("success get by id");
              this.activeLine = activeLine;
              this.activeStations = activeLine.activeStations;
              this.activeStationsToDisplay = this.getActiveStationsToDisplay();
            },
            (err: HttpErrorResponse) => {
              console.log("error at get by id");
              if (err.status === 404) {
                this.tripEnded = true;
                sub.unsubscribe();
              }
            }
          );
      });
    } else {
      this._mockLocationService.mockReadLocation$.subscribe(
        (activeLines: ActiveLine[]) => {
          let currentLine = activeLines.find(line => line.id === this.activeLineId);
          this.activeLine = currentLine !== undefined ? currentLine : this.activeLine;
          this.activeStations = this.activeLine.activeStations;
          this.activeStationsToDisplay = this.getActiveStationsToDisplay();
        }
      );
    }
  }

  protected onNavigateClick(url: string): void {
    this._router.navigate([url]);
  }

  protected getActiveStationLabel(activeStation: ActiveStation): string {
    let label = `${activeStation.name} (${this.getActiveStationStatus(activeStation)})`;

    if (this.isLastPassedStation(activeStation)) {
      let date = new Date(this.activeLine.timestamp);
      let displayDate = `${date.getHours()}:${date.getMinutes()}`;
      label = `${label} - Last updated at ${displayDate}`;
    }

    return label;
  }

  private getActiveStationStatus(activeStation: ActiveStation): string {
    if (activeStation.isActive) return 'Active';
    if (activeStation.isPassed) return 'Passed';

    return 'Not reached';
  }

  private updateActiveLineData(): void {
    combineLatest([
      this._activeLineService.getActiveLineById(this.activeLineId),
      this._activeStationService.getActiveStationsForActiveLineId(this.activeLineId)
    ])
    .subscribe(
      ([activeLine, activeStations]) => {
        this.activeLine = activeLine;
        this.activeStations = activeStations;
        this.activeStationsToDisplay = this.getActiveStationsToDisplay();
      },
      (err: HttpErrorResponse) => {
        if (err.status === 404) {
          this.tripEnded = true;
        }
      }
    );
  }

  private getActiveStationsToDisplay(): ActiveStation[] {
    this.activeStations.reverse();
    let lastPassedStationIndex = this.activeStations.length - 1 - this.activeStations.indexOf(this.activeStations.find(station => station.isPassed));
    console.log(lastPassedStationIndex);
    this.activeStations.reverse();
    return this.activeStations.slice(lastPassedStationIndex - 3, this.activeStations.length);
  }

  private isLastPassedStation(activeStation: ActiveStation): boolean {
    this.activeStations.reverse();
    let lastActiveStation = this.activeStations.find(station => station.isPassed);
    this.activeStations.reverse();

    return this.areActiveStationsEqual(activeStation, lastActiveStation);
  }

  private isComponentDisplayedForRegisterActiveLine(): boolean {
    return this.activeLineId !== undefined;
  }

  public areActiveStationsEqual(
    firstActiveStation: ActiveStation,
    secondActiveStation: ActiveStation): boolean {
    return secondActiveStation.id === firstActiveStation.id &&
           secondActiveStation.name === firstActiveStation.name &&
           secondActiveStation.isActive === firstActiveStation.isActive &&
           secondActiveStation.isPassed === firstActiveStation.isPassed &&
           secondActiveStation.latitude === firstActiveStation.latitude &&
           secondActiveStation.longitude === firstActiveStation.longitude &&
           secondActiveStation.activeLineId === firstActiveStation.activeLineId;
}

}
