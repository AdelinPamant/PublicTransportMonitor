import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { combineLatest } from 'rxjs';

import { ActiveLineService, ActiveStationService } from 'src/app/api/services';
import { ActiveLine, ActiveStation, Station } from 'src/app/api/models';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-active-line-details',
  templateUrl: './active-line-details.component.html',
  styleUrls: ['./active-line-details.component.scss']
})
export class ActiveLineDetailsComponent implements OnInit {

  @Input() activeLineId: string;
  protected tripEnded: boolean = false;
  protected activeLine: ActiveLine;
  protected activeStations: ActiveStation[];

  constructor(
    private readonly _activeLineService: ActiveLineService,
    private readonly _activeStationService: ActiveStationService,
    private readonly _route: ActivatedRoute) { }

  ngOnInit() {
    if (!this.isComponentDisplayedForRegisterActiveLine()) {
      this.activeLineId = this._route.snapshot.paramMap.get('id');
    }

    let sub = this._activeLineService.refreshDataFromFunc(() => {
      this._activeLineService.getActiveLineById(this.activeLineId)
        .subscribe(
          (activeLine: ActiveLine) => {
            console.log("success get by id");
            this.activeLine = activeLine;
          },
          (err: HttpErrorResponse) => {
            console.log("error at get by id");
            if (err.status === 404) {
              this.tripEnded = true;
              sub.unsubscribe();
            }
          }
        );
    });
  }

  private updateActiveLineData(): void {
    combineLatest([
      this._activeLineService.getActiveLineById(this.activeLineId),
      this._activeStationService.getActiveStationsForActiveLineId(this.activeLineId)
    ])
    .subscribe(
      ([activeLine, activeStations]) => {
        this.activeLine = activeLine;
        this.activeStations = activeStations;
      },
      (err: HttpErrorResponse) => {
        if (err.status === 404) {
          this.tripEnded = true;
        }
      }
    );
  }

  private isComponentDisplayedForRegisterActiveLine(): boolean {
    return this.activeLineId !== undefined;
  }

}
