import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveLineDetailsComponent } from './active-line-details.component';

describe('ActiveLineDetailsComponent', () => {
  let component: ActiveLineDetailsComponent;
  let fixture: ComponentFixture<ActiveLineDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveLineDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveLineDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
