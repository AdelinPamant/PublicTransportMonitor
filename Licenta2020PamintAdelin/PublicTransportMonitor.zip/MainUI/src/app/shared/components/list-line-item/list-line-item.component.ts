import { Component, OnChanges, Input } from '@angular/core';

import { ActiveLine } from '../../../api/models';

@Component({
  selector: 'app-list-line-item',
  templateUrl: './list-line-item.component.html',
  styleUrls: ['./list-line-item.component.scss']
})
export class ListLineItemComponent {

  @Input() activeLine: ActiveLine;

  /**
   * CodeReview_UI:
   * - mark methods and properties as being private only these are not used for bindings in UI (.html file).
   *   when I see private methods I usually think that these are not exposed outside.
   *   The ones which are used in UI you can put them as protected or public, and the ones which are used only inside the .ts file can pe put as private.
   *
   * - These changes should be taken into consideration on all files.
   */

  // ngOnChanges(): void {
  //   /*
  //    * CodeRewiew_UI:
  //    * We can increase the readability and the understanding of the business logic if we change ActiveLine from an interface to a class.
  //    * And when retrieving data using ActiveLineService.ts we can map the received data to ActiveLine instances.
  //    *
  //    * By doing this:
  //    *    - we can remove all properties from above and on the html file we can bind directly to "activeLine.name" instead of "_activeLineName".
  //    *      This will reduce the code from the component.
  //    *
  //    *    - by being classes we can add business logic to them. For example we can have a public getter which returns the startStation, lastStation and any other things.
  //    *      Example "public get startStation(): string {return this.activeStations[0].name}" and in html we can bind directly to it {activeLine.startStation}
  //    */
  // }

  // TODO: add validations because for now lines with no active station can be added
  // which leads to redundant data in the database
}
