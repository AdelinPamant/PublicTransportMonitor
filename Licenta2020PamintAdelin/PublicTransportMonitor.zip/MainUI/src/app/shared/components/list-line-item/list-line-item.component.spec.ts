import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListLineItemComponent } from './list-line-item.component';

describe('ListLineItemComponent', () => {
  let component: ListLineItemComponent;
  let fixture: ComponentFixture<ListLineItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListLineItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListLineItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
