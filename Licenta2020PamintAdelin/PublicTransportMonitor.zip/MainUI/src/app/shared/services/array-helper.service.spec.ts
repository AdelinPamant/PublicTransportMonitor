import { TestBed } from '@angular/core/testing';

import { ArrayHelperService } from './array-helper.service';

describe('ArrayHelperService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ArrayHelperService = TestBed.get(ArrayHelperService);
    expect(service).toBeTruthy();
  });
});
