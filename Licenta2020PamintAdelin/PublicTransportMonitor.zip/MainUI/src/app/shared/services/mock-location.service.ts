import { Injectable } from '@angular/core';
import { interval } from 'rxjs';
import { take, map, tap } from 'rxjs/operators';

import { CreationMockData } from '../mock-data/creation-mock-data';
import { ReadMockData } from '../mock-data/read-mock-data';
import { ActiveLine } from 'src/app/api/models';

@Injectable({
  providedIn: 'root'
})
export class MockLocationService {

  private _creationMockData = new CreationMockData();
  private _readMockData = new ReadMockData();

  private _positionCreateData: Position[] = this._creationMockData.line28;
  private _positionReadData: ActiveLine[][] = this._readMockData.readActiveLines;
  private _index: number = 0;

  public mockCreationLocation$ = interval(5000)
    .pipe(
      take(this._positionCreateData.length),
      map(index => this._positionCreateData[index])
    );

  public mockReadLocation$ = interval(2000)
    .pipe(
      map(() => {
        var activeLines = this._positionReadData[this._index];
        activeLines.forEach(activeLine => activeLine.timestamp = Date.now());

        return activeLines;
      }),
      tap(() => {
        if (this._index >= this._positionReadData.length - 1) {
          this._index = 0;
        } else {
          this._index++;
        }
      })
    );
}