import { Injectable } from '@angular/core';
import { interval } from 'rxjs';
import { take, map } from 'rxjs/operators';
import { CreationMockData } from '../mock-data/creation-mock-data';

@Injectable({
  providedIn: 'root'
})
export class MockLocationService {

  private _creationMockData = new CreationMockData();

  private _positionData = this._creationMockData.line28;

  public mockLocation$ = interval(5000)
    .pipe(
      take(this._positionData.length),
      map(index => this._positionData[index])
    );
}
