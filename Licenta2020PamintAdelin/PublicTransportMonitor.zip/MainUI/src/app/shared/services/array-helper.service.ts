import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArrayHelperService<T> {

  public areArraysTheSame(firstArray: Array<T>, secondArray: Array<T>): boolean {
    if (firstArray.length !== secondArray.length) {
      return false;
    }

    let found = false;

    for (let i = 0; i < firstArray.length; i++) {
      for (let j = 0; j < secondArray.length; j++) {
        let tempFirstArrayValue = JSON.stringify(firstArray[i]);
        if (tempFirstArrayValue === JSON.stringify(secondArray[j])) {
          found = true;
        }
      }
      if (!found) {
        return false;
      }
      found = false;
    }

    return true;
  }

}
