import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  public get watchId(): number { return this._watchId }
  private _watchId: number;
  private readonly _trackingOptions = {
    enableHighAccuracy: true
  }

  /*
   * CodeReview_UI:
   * - when using TypeScript try to always add if a method is public/protected/private. In this way it's easier to understand the visibility of the methods.
   *   Because most of the rime we forget to add these things, we don't know when looking on the code if it should be visible outside of the class or not.
   *   It's also easier when you want to refactor, because when you see private method you know that it's used only in that class. When yo see a public method,
   *   you know that when refactoring you have to be more careful because it is used outside of the class as well.
   *
   * - Best practices when using typescript:
   *    - add the visibility of th method, property and so on.
   *    - add a return type on a function/getter, even if it's void.
   *    - add the type of parameters received by a method, or of properties of a class (there are few cases when it's too hard to do that so we can add them as exception)
   *    - if the constructor is needed, it can be removed
   *    - if a property/variable shouldn't be changed besides it's initialization or constructor, just mark it as readonly. For example _trackingOptions
   *
   * * - These changes should be taken into consideration on all files.
   */

  public startTracking(successFunction: PositionCallback): void {
    if (navigator.geolocation) {
      this._watchId = navigator.geolocation.watchPosition(successFunction, this.errorFunction, this._trackingOptions);
    }
  }

  public clearWatchId(): void {
    navigator.geolocation.clearWatch(this.watchId);
  }

  private errorFunction(): void {
    console.error("problem at geolocation");
  }
}
