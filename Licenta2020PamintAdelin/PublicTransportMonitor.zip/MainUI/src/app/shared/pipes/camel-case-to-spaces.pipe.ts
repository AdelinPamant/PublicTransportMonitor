import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'camelCaseToSpaces'
})
export class CamelCaseToSpacesPipe implements PipeTransform {

  transform(value: string): string {
    let result = value.charAt(0) + value.slice(1).replace(/[A-Z]/g, (val: string) => ' ' + val.toLowerCase());

    return result;
  }
}
