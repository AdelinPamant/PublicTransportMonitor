export class CreationMockData {
    
    public get line28(): Position[] {
        return [
            this.buildPosition(47.15386617, 27.58734652, Date.now()),
            this.buildPosition(47.1593497780, 27.5871055126, Date.now()),
            this.buildPosition(47.1614485648, 27.5941125155, Date.now()),
            this.buildPosition(47.1658647196, 27.5893199443, Date.now()),
            this.buildPosition(47.1685132149, 27.5795438291, Date.now()),
            this.buildPosition(47.1755528586, 27.5717053414, Date.now())
        ];
    }

    private buildPosition(
        latitude: number,
        longitude: number,
        timestamp: number): Position {
          return {
            coords: {
                latitude: latitude,
                longitude: longitude,
                accuracy: null,
                altitude: null,
                altitudeAccuracy: null,
                heading: null,
                speed: null
            },
            timestamp: timestamp
          }
      }
}