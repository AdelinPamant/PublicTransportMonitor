export class ReadMockData {
    
}