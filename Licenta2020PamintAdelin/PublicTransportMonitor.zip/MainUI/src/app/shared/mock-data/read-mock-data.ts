import { ActiveLine, ActiveStation } from 'src/app/api/models';

export class ReadMockData {

    public get readActiveLines(): ActiveLine[][] {
        return [
            [this.buildLine(this.line28Details, this.line28Stations, 47.153866, 27.587346, 'InStation', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.145278, 27.594761, 'InStation', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146240, 27.589393, 'InStation', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.173554, 27.558433, 'InStation', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.19053, 27.55849, 'InStation', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.154141, 27.586918, 'JustLeftStation', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.146002, 27.593954, 'JustLeftStation', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146117, 27.589422, 'JustLeftStation', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.173640, 27.558513, 'JustLeftStation', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190632, 27.558518, 'JustLeftStation', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.154488, 27.586561, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.146499, 27.593183, 'Running', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146083, 27.589066, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.173505, 27.559558, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190477, 27.558598, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.155008, 27.585949, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.147441, 27.592035, 'Running', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146057, 27.588820, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.173305, 27.560720, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190405, 27.558806, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.155985, 27.585221, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.147886, 27.592581, 'Running', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146042, 27.588589, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172999, 27.561504, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190398, 27.559015, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.156610, 27.585017, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.148265, 27.593182, 'Running', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146035, 27.588321, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172734, 27.562445, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190269, 27.559121, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.157165, 27.585017, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.148791, 27.593825, 'WithinStationRange', 'Casa Sindicatelor'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146042, 27.588112, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172555, 27.562928, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.190135, 27.559231, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.157434, 27.585021, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.149652, 27.595154, 'InStation', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146050, 27.587892, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172315, 27.563636, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189977, 27.559383, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.158134, 27.585149, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.149709, 27.595148, 'JustLeftStation', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146050, 27.587672, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172256, 27.564194, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189828, 27.559504, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.158542, 27.585321, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.150114, 27.595708, 'Running', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146050, 27.587425, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172344, 27.564677, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189681, 27.559629, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.158834, 27.585750, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.150727, 27.596437, 'Running', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146053, 27.587205, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172512, 27.565374, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189470, 27.559804, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159097, 27.586265, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.151204, 27.597043, 'Running', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146061, 27.587028, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172417, 27.566114, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189341, 27.559925, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159243, 27.586823, 'Running', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.151493, 27.597559, 'Running', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146061, 27.586862, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.172176, 27.566823, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189217, 27.560031, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159302, 27.586943, 'WithinStationRange', 'Sala Polivalenta'),
            this.buildLine(this.line42Details, this.line42Stations, 47.151937, 27.598197, 'WithinStationRange', 'Tesatura'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146064, 27.586722, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.171906, 27.567531, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189116, 27.560115, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159349, 27.587105, 'InStation', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.152114, 27.598600, 'InStation', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146057, 27.586502, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.171564, 27.568314, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.189000, 27.560214, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159390, 27.587187, 'JustLeftStation', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.152401, 27.598834, 'JustLeftStation', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146068, 27.586234, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.171410, 27.568915, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188887, 27.560312, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159473, 27.587536, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.152773, 27.599289, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146068, 27.585901, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.171199, 27.569784, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188758, 27.560415, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159524, 27.587794, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153175, 27.599775, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146072, 27.585660, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.171068, 27.570320, 'Running', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188603, 27.560563, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159627, 27.588113, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153485, 27.600245, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146083, 27.585370, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170973, 27.570846, 'WithinStationRange', 'Petru Poni'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188451, 27.560692, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159731, 27.588416, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153485, 27.600245, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146075, 27.585129, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170865, 27.570910, 'InStation', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188320, 27.560802, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159823, 27.588750, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153640, 27.600730, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146079, 27.584909, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170907, 27.571039, 'JustLeftStation', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188188, 27.560912, 'Running', 'Copou')




            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159896, 27.588993, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153753, 27.601413, 'Running', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146101, 27.584678, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170769, 27.571661, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.188036, 27.561033, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.159978, 27.589251, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153928, 27.602293, 'WithinStationRange', 'Scoala Ion Ghica'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146130, 27.584474, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170455, 27.572305, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187838, 27.561109, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160061, 27.589509, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153901, 27.602768, 'InStation', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146174, 27.584287, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170287, 27.572954, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187691, 27.561276, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160143, 27.589782, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153846, 27.603022, 'JustLeftStation', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146243, 27.584120, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170119, 27.573512, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187554, 27.561462, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160226, 27.590116, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153784, 27.603568, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146331, 27.583927, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.169623, 27.575143, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187441, 27.561568, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160329, 27.590389, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.153959, 27.604038, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146384, 27.583752, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.170061, 27.574510, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187263, 27.561708, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160515, 27.590905, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.154124, 27.604068, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146464, 27.583553, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.169991, 27.574745, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.187103, 27.561829, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160618, 27.591314, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.154434, 27.604129, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146621, 27.583183, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.169750, 27.576118, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186892, 27.561966, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160731, 27.591694, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.154867, 27.604220, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146676, 27.583001, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.169189, 27.577191, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186711, 27.562118, 'Running', 'Copou')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160855, 27.592088, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.155167, 27.604342, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146745, 27.582802, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.168751, 27.578672, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186549, 27.562247, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.160958, 27.592422, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.155538, 27.604311, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146836, 27.582609, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.168320, 27.579906, 'Running', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186459, 27.562338, 'Running', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161041, 27.592695, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.155775, 27.604114, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.146927, 27.582427, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.168051, 27.580689, 'WithinStationRange', 'Blocuri Pacurari'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186392, 27.562380, 'WithinStationRange', 'Copou')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161123, 27.592998, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156054, 27.603932, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147040, 27.582261, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.167916, 27.580825, 'InStation', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.18646, 27.56235, 'InStation', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161237, 27.593347, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156054, 27.603932, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147135, 27.582121, 'Running', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.167883, 27.581022, 'JustLeftStation', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186294, 27.562467, 'JustLeftStation', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161340, 27.593651, 'Running', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156054, 27.603932, 'Running', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147215, 27.581982, 'WithinStationRange', 'Piata Nicolina'),
            this.buildLine(this.line43Details, this.line43Stations, 47.167540, 27.582373, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186196, 27.562554, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161387, 27.594029, 'WithinStationRange', 'Palatul Culturii'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156456, 27.603568, 'WithinStationRange', 'C.T.P. - Sectia nr. 1'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147422, 27.581943, 'InStation', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.167132, 27.584047, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.186067, 27.562664, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161448, 27.594112, 'InStation', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156376, 27.603750, 'InStation', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147329, 27.581783, 'JustLeftStation', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.166825, 27.585399, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185969, 27.562747, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161572, 27.594324, 'JustLeftStation', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.156735, 27.603173, 'JustLeftStation', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147406, 27.581592, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.166439, 27.586794, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185873, 27.562831, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161649, 27.594869, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.157096, 27.602885, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147493, 27.581527, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.166140, 27.587824, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185636, 27.563013, 'Running', 'Stadion')




            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.161992, 27.594942, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.157663, 27.602217, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147570, 27.581447, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.165870, 27.589143, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185451, 27.563187, 'Running', 'Stadion')



            ],
            [this.buildLine(this.line28Details, this.line28Stations, 47.162299, 27.594725, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158014, 27.602005, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147657, 27.581280, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.165403, 27.590484, 'Running', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185324, 27.563278, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.162716, 27.594364, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158365, 27.601671, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147778, 27.581098, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.164848, 27.590785, 'WithinStationRange', 'Piata Independentei'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185195, 27.563400, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.162974, 27.594075, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158561, 27.601352, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.147880, 27.580943, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.16472, 27.59092, 'InStation', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.185043, 27.563525, 'Running', 'Stadion')




            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.163244, 27.593715, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158809, 27.601186, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148078, 27.580642, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.164389, 27.591235, 'JustLeftStation', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184865, 27.563662, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.163489, 27.593354, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158809, 27.600579, 'Running', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148187, 27.580417, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.163944, 27.592319, 'Running', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184700, 27.563825, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.163624, 27.593029, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158984, 27.600245, 'WithinStationRange', 'Tudor Vladimirescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148330, 27.580208, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.163404, 27.593531, 'Running', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184590, 27.563901, 'Running', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.163796, 27.592668, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.158988, 27.600078, 'InStation', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148443, 27.580015, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.162821, 27.594272, 'Running', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184517, 27.563957, 'WithinStationRange', 'Stadion')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.163955, 27.592289, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.159211, 27.599911, 'JustLeftStation', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148548, 27.579832, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.162091, 27.594851, 'Running', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.18459, 27.56394, 'InStation', 'George Cosbuc')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164133, 27.591856, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.159500, 27.599350, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148643, 27.579687, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.161755, 27.595130, 'WithinStationRange', 'Targu Cucu'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184438, 27.564026, 'JustLeftStation', 'George Cosbuc')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164133, 27.591856, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.159747, 27.598925, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148771, 27.579500, 'Running', 'Vama'),
            this.buildLine(this.line43Details, this.line43Stations, 47.161380, 27.595607, 'InStation', 'Elena Doamna'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184340, 27.564092, 'Running', 'George Cosbuc')



            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164336, 27.591342, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160016, 27.598363, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.148859, 27.579376, 'WithinStationRange', 'Vama'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184224, 27.564206, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164421, 27.591152, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160243, 27.597787, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149047, 27.579282, 'InStation', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.184075, 27.564324, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164605, 27.591008, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160425, 27.597323, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149067, 27.579087, 'JustLeftStation', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183967, 27.564407, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164740, 27.590927, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160641, 27.596966, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149169, 27.578942, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183871, 27.564498, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.164918, 27.590792, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160806, 27.596532, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149278, 27.578740, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183758, 27.564589, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165127, 27.590647, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.160954, 27.596238, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149406, 27.578542, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183662, 27.564654, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165329, 27.590548, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.161205, 27.595830, 'Running', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149526, 27.578386, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183534, 27.564767, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165507, 27.590422, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.161531, 27.595389, 'WithinStationRange', 'Bucsinescu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149632, 27.578236, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183392, 27.564896, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165587, 27.590133, 'Running', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.161012, 27.596099, 'InStation', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149800, 27.578043, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183232, 27.565033, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165685, 27.589943, 'WithinStationRange', 'Elena Doamna'),
            this.buildLine(this.line42Details, this.line42Stations, 47.161799, 27.595192, 'JustLeftStation', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.149909, 27.577893, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.183098, 27.565154, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165864, 27.589319, 'InStation', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.162104, 27.594929, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150044, 27.577683, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182951, 27.565268, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165737, 27.589567, 'JustLeftStation', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.162393, 27.594717, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150154, 27.577528, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182855, 27.565348, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.165792, 27.589261, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.162769, 27.594445, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150256, 27.577362, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182644, 27.565549, 'Running', 'George Cosbuc')

            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.166191, 27.588034, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.163068, 27.594127, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150358, 27.577265, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182422, 27.565704, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.166436, 27.586951, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.163336, 27.593778, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150483, 27.577128, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182257, 27.565845, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.166829, 27.585616, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.163532, 27.593353, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150603, 27.576914, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.182100, 27.565974, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167025, 27.584353, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.163749, 27.592852, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150742, 27.576721, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181963, 27.566091, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167135, 27.584028, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.163976, 27.592427, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.150881, 27.576511, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181837, 27.566163, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167344, 27.582999, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.164110, 27.592003, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151074, 27.576270, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181768, 27.566251, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167528, 27.582476, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.164255, 27.591259, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151183, 27.576088, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181631, 27.566353, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167626, 27.581863, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.164605, 27.591062, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151289, 27.575916, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181453, 27.566490, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167773, 27.581412, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.164986, 27.590816, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151421, 27.575766, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181329, 27.566603, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.167964, 27.580872, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165265, 27.590573, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151588, 27.575519, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181169, 27.566751, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168074, 27.580523, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165585, 27.590300, 'Running', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151650, 27.575438, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181074, 27.566831, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168187, 27.580207, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165719, 27.589906, 'WithinStationRange', 'Elena Doamna'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151785, 27.575235, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.181010, 27.566952, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168285, 27.579890, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165788, 27.589631, 'InStation', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.151993, 27.574966, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180917, 27.567036, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168405, 27.579585, 'Running', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165801, 27.589618, 'JustLeftStation', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.152179, 27.574730, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180811, 27.567115, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168467, 27.579477, 'WithinStationRange', 'Targu Cucu'),
            this.buildLine(this.line42Details, this.line42Stations, 47.165946, 27.589223, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.152380, 27.574510, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180672, 27.567225, 'Running', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168513, 27.579543, 'InStation', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166008, 27.588813, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.152592, 27.574323, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180561, 27.567328, 'WithinStationRange', 'George Cosbuc')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168559, 27.579263, 'JustLeftStation', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166224, 27.588237, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.152763, 27.574189, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.18056, 27.56736, 'InStation', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168639, 27.579027, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166369, 27.587554, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.152898, 27.574054, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180468, 27.567362, 'JustLeftStation', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168785, 27.578737, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166482, 27.586735, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.153073, 27.573953, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180393, 27.567408, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.168850, 27.578405, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166668, 27.585976, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.153277, 27.573840, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180254, 27.567525, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169033, 27.578136, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.166833, 27.585339, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.153453, 27.573770, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180123, 27.567646, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169186, 27.577707, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167029, 27.584565, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.153613, 27.573695, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.180032, 27.567726, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169346, 27.577299, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167297, 27.583655, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.153830, 27.573663, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179891, 27.567836, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169565, 27.577085, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167442, 27.582987, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.154075, 27.573588, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179757, 27.567958, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169799, 27.576935, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167565, 27.582456, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.154297, 27.573556, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179628, 27.568068, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.169952, 27.576677, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167699, 27.581925, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.154534, 27.573545, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179334, 27.568310, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.170090, 27.576259, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.167844, 27.581409, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.154768, 27.573582, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179212, 27.568420, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.170348, 27.575969, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168081, 27.580878, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.154983, 27.573641, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.179102, 27.568519, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.170596, 27.575797, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168174, 27.580332, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.155227, 27.573647, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178952, 27.568637, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.170807, 27.575582, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168360, 27.579831, 'Running', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.155366, 27.573706, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178797, 27.568765, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.171084, 27.575379, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168525, 27.579558, 'WithinStationRange', 'Targu Cucu'),
            this.buildLine(this.line30Details, this.line30Stations, 47.155603, 27.573792, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178656, 27.568898, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.171340, 27.575132, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168471, 27.579577, 'InStation', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.155753, 27.573915, 'Running', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178305, 27.569183, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.171668, 27.574831, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168679, 27.579133, 'JustLeftStation', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.155913, 27.573995, 'WithinStationRange', 'Gara Internationala'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178163, 27.569308, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.171989, 27.574542, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168814, 27.578754, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156297, 27.574211, 'InStation', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.178094, 27.569384, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.172310, 27.574273, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.168948, 27.578374, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156114, 27.574087, 'JustLeftStation', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177977, 27.569482, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.172645, 27.573973, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.169164, 27.577889, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156260, 27.574151, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177864, 27.569604, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.172981, 27.573716, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.169371, 27.577403, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156413, 27.574237, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177681, 27.569759, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.173236, 27.573480, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.169721, 27.577100, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156584, 27.574323, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177488, 27.569907, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.173418, 27.573308, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.169989, 27.576736, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156770, 27.574457, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177292, 27.570089, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.173783, 27.573029, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.170144, 27.576296, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.156942, 27.574521, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.177103, 27.570249, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.174053, 27.572836, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.170464, 27.576007, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157099, 27.574612, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176936, 27.570359, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.174272, 27.572621, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.170763, 27.575719, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157252, 27.574693, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176758, 27.570510, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.174454, 27.572482, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.170980, 27.575461, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157434, 27.574795, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176639, 27.570620, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.174709, 27.572267, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.171299, 27.575173, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157628, 27.574923, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176454, 27.570757, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.175008, 27.572020, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.171526, 27.574930, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157788, 27.575020, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176283, 27.570905, 'Running', 'Triumf')

            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.175234, 27.571838, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.171784, 27.574748, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.157952, 27.575127, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.176131, 27.571022, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.175415, 27.571706, 'Running', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.171990, 27.574521, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.158127, 27.575261, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175977, 27.571136, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.175445, 27.571684, 'WithinStationRange', 'Piata Independentei'),
            this.buildLine(this.line42Details, this.line42Stations, 47.172228, 27.574384, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.158310, 27.575374, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175897, 27.571189, 'Running', 'Triumf')

            ],

            [this.buildLine(this.line28Details, this.line28Stations, 47.175552, 27.571705, 'InStation', 'Universitate'),
            this.buildLine(this.line42Details, this.line42Stations, 47.172475, 27.574187, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.158532, 27.575503, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175757, 27.571311, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.172723, 27.573989, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.158733, 27.575503, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175660, 27.571390, 'Running', 'Triumf')
            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.172929, 27.573792, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.158926, 27.575481, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175742, 27.571330, 'Running', 'Triumf')
            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.173135, 27.573610, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159083, 27.575283, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175641, 27.571417, 'Running', 'Triumf')
            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.173434, 27.573398, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159130, 27.575041, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175507, 27.571527, 'Running', 'Triumf')
            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.173501, 27.573307, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159039, 27.574746, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175430, 27.571588, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.173742, 27.573136, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159047, 27.574398, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175355, 27.571675, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.173983, 27.572905, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159160, 27.574103, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175268, 27.571739, 'Running', 'Triumf')

            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174145, 27.572771, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159236, 27.573877, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175152, 27.571842, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174296, 27.572645, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159404, 27.573566, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.175072, 27.571910, 'Running', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174415, 27.572554, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159586, 27.573405, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.174997, 27.571963, 'WithinStationRange', 'Triumf')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174612, 27.572409, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159754, 27.573185, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.17496, 27.57204, 'InStation', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174712, 27.572323, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.159947, 27.573132, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.174917, 27.572047, 'JustLeftStation', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.174871, 27.572213, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.160177, 27.573083, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.174638, 27.572274, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175001, 27.572085, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.160454, 27.573089, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.174301, 27.572540, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175090, 27.572002, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.160615, 27.573132, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.173937, 27.572839, 'Running', 'Universitate')

            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175226, 27.571897, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.160783, 27.573132, 'Running', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.173612, 27.573124, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175322, 27.571814, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.161111, 27.573191, 'WithinStationRange', 'Podu de Piatra'),
            this.buildLine(this.line36Details, this.line36Stations, 47.173298, 27.573408, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175378, 27.571741, 'Running', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.161463, 27.573295, 'InStation', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.173213, 27.573511, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175475, 27.571687, 'WithinStationRange', 'Piata Independentei'),
            this.buildLine(this.line30Details, this.line30Stations, 47.161297, 27.573212, 'JustLeftStation', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.172821, 27.573841, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line42Details, this.line42Stations, 47.175396, 27.571799, 'InStation', 'Universitate'),
            this.buildLine(this.line30Details, this.line30Stations, 47.161494, 27.573266, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.172359, 27.574232, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.161717, 27.573271, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.172008, 27.574501, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.161935, 27.573287, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.171518, 27.574914, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.162118, 27.573255, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.171031, 27.575225, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.162368, 27.573220, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.170464, 27.575665, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.162583, 27.573070, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.169961, 27.576102, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.162780, 27.572936, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.169476, 27.576401, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.163002, 27.572813, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.169120, 27.576602, 'Running', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.163221, 27.572700, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.169017, 27.576652, 'WithinStationRange', 'Universitate')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.163451, 27.572560, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.168953, 27.576610, 'InStation', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.163699, 27.572405, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.168918, 27.576636, 'JustLeftStation', '')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.163899, 27.572314, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.168493, 27.576837, 'Running', 'Piata Mihai Eminescu')

            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.164100, 27.572217, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.168075, 27.576955, 'Running', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.164279, 27.572088, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.167546, 27.577084, 'Running', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.164483, 27.571954, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.167002, 27.577281, 'Running', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.164716, 27.571879, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.166566, 27.577535, 'Running', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.164892, 27.571777, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.166399, 27.577490, 'Running', 'Piata Mihai Eminescu')


            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.165056, 27.571745, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.166592, 27.576940, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.165223, 27.571707, 'Running', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.166927, 27.575642, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.165406, 27.571632, 'WithinStationRange', 'Pasaj Alexandru cel Bun'),
            this.buildLine(this.line36Details, this.line36Stations, 47.167208, 27.574668, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line30Details, this.line30Stations, 47.165609, 27.571442, 'InStation', 'Gara'),
            this.buildLine(this.line36Details, this.line36Stations, 47.167342, 27.574273, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.167226, 27.573939, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.166801, 27.572866, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.166399, 27.571808, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.166074, 27.571019, 'Running', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.165939, 27.571132, 'WithinStationRange', 'Piata Mihai Eminescu')
            ],

            [this.buildLine(this.line36Details, this.line36Stations, 47.165609, 27.571442, 'InStation', 'Gara')
            ]
        ]
    }

    // private buildLine42(latitude: number, longitude: number, activeStationIndex: number): ActiveLine {
    //     return 
    // }

    // private buildLine41(latitude: number, longitude: number, activeStationIndex: number): ActiveLine {
    //     return {
    //         id: "4",
    //         name: "41",
    //         userLatitude: latitude,
    //         userLongitude: longitude,
    //         activeStations: this.buildLineStations(this.line41Stations, activeStationIndex),
    //         nextStation: "Targu Cucu",
    //         nextStationStatus: "InStation",
    //         timestamp: Date.now(),
    //         type: null
    //     }
    // }

    // private buildLine36(latitude: number, longitude: number, activeStationIndex: number): ActiveLine {
    //     return {
    //         id: "3",
    //         name: "36",
    //         userLatitude: latitude,
    //         userLongitude: longitude,
    //         activeStations: this.buildLineStations(this.line36Stations, activeStationIndex),
    //         nextStation: "Stadion",
    //         nextStationStatus: "InStation",
    //         timestamp: Date.now(),
    //         type: null
    //     }
    // }

    // private buildLine30(latitude: number, longitude: number, activeStationIndex: number): ActiveLine {
    //     return {
    //         id: "2",
    //         name: "30",
    //         userLatitude: latitude,
    //         userLongitude: longitude,
    //         activeStations: this.buildLineStations(this.line30Stations, activeStationIndex),
    //         nextStation: "Vama",
    //         nextStationStatus: "InStation",
    //         timestamp: Date.now(),
    //         type: null
    //     }
    // }

    // private buildLine28(latitude: number, longitude: number, activeStationIndex: number): ActiveLine {
    //     return {
    //         id: "1",
    //         name: "28",
    //         userLatitude: latitude,
    //         userLongitude: longitude,
    //         activeStations: this.buildLineStations(this.line28Stations, activeStationIndex),
    //         nextStation: "Palatul Culturii",
    //         nextStationStatus: "InStation",
    //         timestamp: Date.now(),
    //         type: null
    //     }
    // }

    private buildLine(
        specificActiveLine: ActiveLine,
        specificActiveLineStations: ActiveStation[],
        latitude: number,
        longitude: number,
        nextStationStatus: string,
        lastPassedStation: string,
        activeStation: string = 'NaN'): ActiveLine {

        if (nextStationStatus === 'InStation') activeStation = lastPassedStation;
        let stations: ActiveStation[] = this.buildLineStations(specificActiveLineStations, lastPassedStation, activeStation);

        return {
            ...specificActiveLine,
            userLatitude: latitude,
            userLongitude: longitude,
            nextStation: this.getNextStation(stations),
            nextStationStatus: nextStationStatus,
            activeStations: stations,
            timestamp: Date.now()
        };
    }

    private buildLineStations(stations: ActiveStation[], lastPassedStation: string, activeStation: string): ActiveStation[] {
        let indexOfLastPassedStation = stations.indexOf(stations.find(s => s.name === lastPassedStation));
        var foundActiveStation = stations.find(s => s.name === activeStation);
        let indexOfActiveStation = foundActiveStation !== undefined
            ? stations.indexOf(foundActiveStation)
            : 999;

        for (let i = 0; i < stations.length; i++) {
            this.setstationDetails(stations[i], i, indexOfLastPassedStation, indexOfActiveStation);
        }

        return stations;
    }

    private setstationDetails(station: ActiveStation, stationIndex: number, indexOfLastPassedStation: number, indexOfActiveStation: number): void {
        if (stationIndex <= indexOfLastPassedStation) {
            station.isPassed = true;
            station.isActive = false;
        }
        if (stationIndex === indexOfActiveStation) {
            station.isPassed = true;
            station.isActive = true;
        }
        if (stationIndex > indexOfActiveStation) {
            station.isPassed = false;
            station.isActive = false;
        }
    }

    private getNextStation(stations: ActiveStation[]): string {
        let foundStation = stations.find(s => s.isPassed === false).name;
        return foundStation !== undefined
            ? foundStation
            : '';
    }

    private get line28Details(): ActiveLine {
        return {
            id: "1",
            name: "28",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line28Stations(): ActiveStation[] {
        return [
            {
                "id": "89139352-f359-4976-4dde-08d7ac056ad8",
                "name": "Dacia",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.169591248,
                "longitude": 27.540042400,
                "activeLineId": "1"
            },
            {
                "id": "61ff2f80-f098-4821-4ddf-08d7ac056ad8",
                "name": "Columnei",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.166649930,
                "longitude": 27.544445910,
                "activeLineId": "1"
            },
            {
                "id": "ab1dac73-076c-432c-4de0-08d7ac056ad8",
                "name": "Bicaz",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.166793276,
                "longitude": 27.551117778,
                "activeLineId": "1"
            },
            {
                "id": "7d9fbc2d-cbdb-45a9-4de1-08d7ac056ad8",
                "name": "Zimbru",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.166811512,
                "longitude": 27.555542350,
                "activeLineId": "1"
            },
            {
                "id": "d1333dfa-c62c-47d0-4de2-08d7ac056ad8",
                "name": "Minerva",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.163360526,
                "longitude": 27.564440847,
                "activeLineId": "1"
            },
            {
                "id": "91529684-ddff-4433-4de3-08d7ac056ad8",
                "name": "Familial",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.161960665,
                "longitude": 27.567234635,
                "activeLineId": "1"
            },
            {
                "id": "a5917223-f77e-4fa5-4de4-08d7ac056ad8",
                "name": "Piata Alexandru cel Bun",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.160115768,
                "longitude": 27.570440412,
                "activeLineId": "1"
            },
            {
                "id": "5cbd1aca-1b16-4376-4de5-08d7ac056ad8",
                "name": "Mircea cel Batran",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.156063190,
                "longitude": 27.570342779,
                "activeLineId": "1"
            },
            {
                "id": "d442e534-b063-4504-4de6-08d7ac056ad8",
                "name": "Policlinica Recuperare",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.151878241,
                "longitude": 27.572477817,
                "activeLineId": "1"
            },
            {
                "id": "6e7ef8bf-c283-4e7b-4de7-08d7ac056ad8",
                "name": "Spitalul de Recuperare",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.149746971,
                "longitude": 27.574887514,
                "activeLineId": "1"
            },
            {
                "id": "886c4071-a58e-42b9-4de8-08d7ac056ad8",
                "name": "Gara Internationala",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.147045900,
                "longitude": 27.579889240,
                "activeLineId": "1"
            },
            {
                "id": "690a9413-f31c-4db8-4de9-08d7ac056ad8",
                "name": "Pasaj Nicolina",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.144771244,
                "longitude": 27.582282901,
                "activeLineId": "1"
            },
            {
                "id": "391ad001-ea5e-499a-4dea-08d7ac056ad8",
                "name": "Podu Ros (3)",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.150117840,
                "longitude": 27.586395520,
                "activeLineId": "1"
            },
            {
                "id": "81e83bbf-3755-4d7d-4deb-08d7ac056ad8",
                "name": "Sala Polivalenta",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.153866170,
                "longitude": 27.587346520,
                "activeLineId": "1"
            },
            {
                "id": "11bb79fa-acb5-4bab-4dec-08d7ac056ad8",
                "name": "Palatul Culturii",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.159349778,
                "longitude": 27.587105513,
                "activeLineId": "1"
            },
            {
                "id": "1ba7150d-e125-4449-4ded-08d7ac056ad8",
                "name": "Elena Doamna",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161448565,
                "longitude": 27.594112516,
                "activeLineId": "1"
            },
            {
                "id": "22468c40-4a3b-464e-4dee-08d7ac056ad8",
                "name": "Targu Cucu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.165864720,
                "longitude": 27.589319944,
                "activeLineId": "1"
            },
            {
                "id": "a8a22168-e346-475d-4def-08d7ac056ad8",
                "name": "Piata Independentei",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.168513215,
                "longitude": 27.579543829,
                "activeLineId": "1"
            },
            {
                "id": "6a384a87-730c-4f25-4df0-08d7ac056ad8",
                "name": "Universitate",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.175552859,
                "longitude": 27.571705341,
                "activeLineId": "1"
            },
            {
                "id": "cf739918-8c1d-41cd-4df1-08d7ac056ad8",
                "name": "Triumf",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.180836250,
                "longitude": 27.567291220,
                "activeLineId": "1"
            },
            {
                "id": "bc623deb-bdd2-478f-4df2-08d7ac056ad8",
                "name": "Triumf",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.180560000,
                "longitude": 27.567360000,
                "activeLineId": "1"
            }
        ];
    }

    private get line30Details(): ActiveLine {
        return {
            id: "2",
            name: "30",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line30Stations(): ActiveStation[] {
        return [
            {
                "id": "17827c86-0628-4a05-9af5-08d7aca9d6cc",
                "name": "Bucium",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.116596340,
                "longitude": 27.632140520,
                "activeLineId": "2"
            },
            {
                "id": "cb5f7ef8-b61c-4973-9af6-08d7aca9d6cc",
                "name": "Plopii fara sot",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.119275287,
                "longitude": 27.629611016,
                "activeLineId": "2"
            },
            {
                "id": "c57e4bda-8880-44bc-9af7-08d7aca9d6cc",
                "name": "Scoala Generala nr. 2",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.121041160,
                "longitude": 27.625846710,
                "activeLineId": "2"
            },
            {
                "id": "dfe97894-5588-4465-9af8-08d7aca9d6cc",
                "name": "Hanul Trei Sarmale",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.124368010,
                "longitude": 27.621350884,
                "activeLineId": "2"
            },
            {
                "id": "3a174189-81f6-447d-9af9-08d7aca9d6cc",
                "name": "Centrofarm",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.127843426,
                "longitude": 27.616335154,
                "activeLineId": "2"
            },
            {
                "id": "d36c2b09-bbda-4738-9afa-08d7aca9d6cc",
                "name": "Spitalul nr. 7",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.130513240,
                "longitude": 27.614073400,
                "activeLineId": "2"
            },
            {
                "id": "13860a76-d533-4d3b-9afb-08d7aca9d6cc",
                "name": "OMV Bucium",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.135235139,
                "longitude": 27.609446168,
                "activeLineId": "2"
            },
            {
                "id": "73f9f91b-c709-447f-9afc-08d7aca9d6cc",
                "name": "Frigorifer",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.142051660,
                "longitude": 27.599338850,
                "activeLineId": "2"
            },
            {
                "id": "9f0f5f7e-dc64-4eb4-9afd-08d7aca9d6cc",
                "name": "Casa Sindicatelor",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.145278010,
                "longitude": 27.594761960,
                "activeLineId": "2"
            },
            {
                "id": "2c208cf5-ea99-4756-9afe-08d7aca9d6cc",
                "name": "Piata Nicolina",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.146240150,
                "longitude": 27.589393974,
                "activeLineId": "2"
            },
            {
                "id": "0cf2cb5f-b812-47a4-9aff-08d7aca9d6cc",
                "name": "Vama",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.147422250,
                "longitude": 27.581943870,
                "activeLineId": "2"
            },
            {
                "id": "e8dfa173-aa56-4332-9b00-08d7aca9d6cc",
                "name": "Gara Internationala",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.149047960,
                "longitude": 27.579282045,
                "activeLineId": "2"
            },
            {
                "id": "d08718d4-4453-4c67-9b01-08d7aca9d6cc",
                "name": "Podul de Piatra",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.156297380,
                "longitude": 27.574211598,
                "activeLineId": "2"
            },
            {
                "id": "a14eea4d-fbdd-44e6-9b02-08d7aca9d6cc",
                "name": "Pasaj Alexandru cel Bun (sens Gara)",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161463155,
                "longitude": 27.573295355,
                "activeLineId": "2"
            },
            {
                "id": "2baa7ecd-84c2-4c82-9b03-08d7aca9d6cc",
                "name": "Gara",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.165609418,
                "longitude": 27.571442485,
                "activeLineId": "2"
            },
            {
                "id": "1fb107bc-8d26-4dbe-9b04-08d7aca9d6cc",
                "name": "Str. Bacinschi",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.167418200,
                "longitude": 27.568811910,
                "activeLineId": "2"
            },
            {
                "id": "415bc1bd-9eea-4627-9b05-08d7aca9d6cc",
                "name": "Octav Bancila",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.171485680,
                "longitude": 27.560670080,
                "activeLineId": "2"
            },
            {
                "id": "0c1d73d2-151f-4035-9b06-08d7aca9d6cc",
                "name": "Moara 1 Mai",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.173328840,
                "longitude": 27.553043560,
                "activeLineId": "2"
            },
            {
                "id": "d43795c6-4622-493d-9b07-08d7aca9d6cc",
                "name": "Sergent Grigore Ioan",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.173320433,
                "longitude": 27.544667602,
                "activeLineId": "2"
            },
            {
                "id": "7b184a31-9e33-486b-9b08-08d7aca9d6cc",
                "name": "Canta",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.172323432,
                "longitude": 27.537670255,
                "activeLineId": "2"
            }
        ];
    }

    private get line36Details(): ActiveLine {
        return {
            id: "3",
            name: "36",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line36Stations(): ActiveStation[] {
        return [
            {
                "id": "18f67dc9-7f6c-4274-9b4a-08d7aca9d6cc",
                "name": "Breazu",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.209589550,
                "longitude": 27.531569300,
                "activeLineId": "3"
            },
            {
                "id": "052a9d3c-c4a5-4300-9b4b-08d7aca9d6cc",
                "name": "Statiunea Viticola",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.202778290,
                "longitude": 27.534626000,
                "activeLineId": "3"
            },
            {
                "id": "209b4d2b-5d4c-4271-9b4c-08d7aca9d6cc",
                "name": "Seminarul Teologic",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.200916680,
                "longitude": 27.537719060,
                "activeLineId": "3"
            },
            {
                "id": "01849bd8-1389-419f-9b4d-08d7aca9d6cc",
                "name": "Liceul Pedagogic",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.199727570,
                "longitude": 27.541563490,
                "activeLineId": "3"
            },
            {
                "id": "14b8a26c-7e6c-46e8-9b4e-08d7aca9d6cc",
                "name": "Liceul Agricol",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.198383390,
                "longitude": 27.544630320,
                "activeLineId": "3"
            },
            {
                "id": "fb2368c0-6279-44a5-9b4f-08d7aca9d6cc",
                "name": "Str. Podgoriilor",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.197405280,
                "longitude": 27.550274360,
                "activeLineId": "3"
            },
            {
                "id": "b770c79c-1938-4a03-9b50-08d7aca9d6cc",
                "name": "Muzeul Mihail Sadoveanu",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.195399160,
                "longitude": 27.554686120,
                "activeLineId": "3"
            },
            {
                "id": "c9b34e40-ced4-43e7-9b51-08d7aca9d6cc",
                "name": "Copou",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.190530000,
                "longitude": 27.558490000,
                "activeLineId": "3"
            },
            {
                "id": "b8b2a1c4-3cd5-4947-9b52-08d7aca9d6cc",
                "name": "Stadion",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.186460000,
                "longitude": 27.562350000,
                "activeLineId": "3"
            },
            {
                "id": "a91c4457-de89-4abd-9b53-08d7aca9d6cc",
                "name": "George Cosbuc",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.184590000,
                "longitude": 27.563940000,
                "activeLineId": "3"
            },
            {
                "id": "061c9263-35ea-4bda-9b54-08d7aca9d6cc",
                "name": "Triumf",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.180560000,
                "longitude": 27.567360000,
                "activeLineId": "3"
            },
            {
                "id": "208abc29-6c74-4b73-9b55-08d7aca9d6cc",
                "name": "Universitate",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.174960000,
                "longitude": 27.572040000,
                "activeLineId": "3"
            },
            {
                "id": "314fd35b-1934-44bb-9b56-08d7aca9d6cc",
                "name": "Piata Mihai Eminescu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.168953370,
                "longitude": 27.576610470,
                "activeLineId": "3"
            },
            {
                "id": "be748dd1-a686-43fd-9b57-08d7aca9d6cc",
                "name": "Gara",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.165846110,
                "longitude": 27.571051000,
                "activeLineId": "3"
            },
            {
                "id": "5de56f3a-ce06-4be0-9b58-08d7aca9d6cc",
                "name": "Pasaj Alexandru cel Bun",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161430000,
                "longitude": 27.573120000,
                "activeLineId": "3"
            },
            {
                "id": "9034cba9-d789-4f76-9b59-08d7aca9d6cc",
                "name": "Minerva",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.163298430,
                "longitude": 27.564613040,
                "activeLineId": "3"
            },
            {
                "id": "96acdd13-1e20-4fee-9b5a-08d7aca9d6cc",
                "name": "Zimbru",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.166791190,
                "longitude": 27.555906330,
                "activeLineId": "3"
            },
            {
                "id": "7cfbd3f2-9d89-4d15-9b5b-08d7aca9d6cc",
                "name": "Bicaz",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.166792750,
                "longitude": 27.550011460,
                "activeLineId": "3"
            },
            {
                "id": "fa56d663-fdc9-418f-9b5c-08d7aca9d6cc",
                "name": "Columnei",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.166803330,
                "longitude": 27.544148590,
                "activeLineId": "3"
            },
            {
                "id": "2ef318ec-7bc3-41c2-9b5d-08d7aca9d6cc",
                "name": "Dacia",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.168318690,
                "longitude": 27.541465400,
                "activeLineId": "3"
            }
        ];
    }

    private get line41Details(): ActiveLine {
        return {
            id: "4",
            name: "41",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line41Stations(): ActiveStation[] {
        return [
            {
                "id": "a4d348e2-9ac2-4008-9b09-08d7aca9d6cc",
                "name": "Piata Independentei",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.168471220,
                "longitude": 27.579577750,
                "activeLineId": "4"
            },
            {
                "id": "9b7276e3-f8b5-4496-9b0a-08d7aca9d6cc",
                "name": "Piata Independentei",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.167916860,
                "longitude": 27.580825240,
                "activeLineId": "4"
            },
            {
                "id": "2f41d627-077c-42ec-9b0b-08d7aca9d6cc",
                "name": "Targu Cucu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.164720000,
                "longitude": 27.590920000,
                "activeLineId": "4"
            },
            {
                "id": "4f852148-cbf9-4b06-9b0c-08d7aca9d6cc",
                "name": "Elena Doamna",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161360730,
                "longitude": 27.593528900,
                "activeLineId": "4"
            },
            {
                "id": "e5e07637-86a7-492e-9b0d-08d7aca9d6cc",
                "name": "Palatul Culturii",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.159922590,
                "longitude": 27.588838610,
                "activeLineId": "4"
            },
            {
                "id": "bd074412-91b2-472a-9b0e-08d7aca9d6cc",
                "name": "Sala Polivalenta",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.153847090,
                "longitude": 27.587174310,
                "activeLineId": "4"
            },
            {
                "id": "0a93315b-ee20-4196-9b0f-08d7aca9d6cc",
                "name": "Podu Ros (3)",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.149762140,
                "longitude": 27.585959170,
                "activeLineId": "4"
            },
            {
                "id": "0f0d3a1f-3b87-47cd-9b10-08d7aca9d6cc",
                "name": "Pod Nicolina",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.142717860,
                "longitude": 27.580298780,
                "activeLineId": "4"
            },
            {
                "id": "0db91c16-89ad-40b9-9b11-08d7aca9d6cc",
                "name": "Tudor Neculai",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.139216450,
                "longitude": 27.578350220,
                "activeLineId": "4"
            },
            {
                "id": "3be5fc94-b2ef-4774-9b12-08d7aca9d6cc",
                "name": "C.U.G. I",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.133380390,
                "longitude": 27.572057930,
                "activeLineId": "4"
            },
            {
                "id": "2e089d6e-3aaf-4b38-9b13-08d7aca9d6cc",
                "name": "Biserica Inaltarea Domnului",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.129402110,
                "longitude": 27.569302440,
                "activeLineId": "4"
            },
            {
                "id": "d002d3c5-55bb-4a61-9b14-08d7aca9d6cc",
                "name": "Tehnopolis",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.125094310,
                "longitude": 27.567237200,
                "activeLineId": "4"
            },
            {
                "id": "4e84b54a-0b60-4014-9b15-08d7aca9d6cc",
                "name": "Vama II",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.119496790,
                "longitude": 27.564459980,
                "activeLineId": "4"
            },
            {
                "id": "b58c9829-076d-4729-9b16-08d7aca9d6cc",
                "name": "Otelarie",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.117280010,
                "longitude": 27.563044730,
                "activeLineId": "4"
            },
            {
                "id": "f106800d-f88a-41bb-9b17-08d7aca9d6cc",
                "name": "Baza Nautica",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.114213520,
                "longitude": 27.561039210,
                "activeLineId": "4"
            },
            {
                "id": "eaf3cd87-67a3-4cee-9b18-08d7aca9d6cc",
                "name": "Horpaz",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.110739060,
                "longitude": 27.559610610,
                "activeLineId": "4"
            },
            {
                "id": "a87af0c1-93a1-487a-9b19-08d7aca9d6cc",
                "name": "Sere Ciurea",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.105615580,
                "longitude": 27.559645290,
                "activeLineId": "4"
            },
            {
                "id": "0c1bf5e2-56b9-4b37-9b1a-08d7aca9d6cc",
                "name": "Lunca Cetatuii",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.100665680,
                "longitude": 27.559773650,
                "activeLineId": "4"
            },
            {
                "id": "b14f5417-ef6d-4b06-9b1b-08d7aca9d6cc",
                "name": "Astoria",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.097188090,
                "longitude": 27.559003170,
                "activeLineId": "4"
            },
            {
                "id": "4ab41d42-60d2-4af7-9b1c-08d7aca9d6cc",
                "name": "Blocuri Ciurea",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.096700780,
                "longitude": 27.561191830,
                "activeLineId": "4"
            },
            {
                "id": "ead33206-b074-464d-9b1d-08d7aca9d6cc",
                "name": "Blocuri Ciurea",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.096640000,
                "longitude": 27.566590000,
                "activeLineId": "4"
            }
        ];
    }

    private get line42Details(): ActiveLine {
        return {
            id: "6",
            name: "42",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line42Stations(): ActiveStation[] {
        return [
            {
                "id": "16be5baa-024b-4c3a-9b1e-08d7aca9d6cc",
                "name": "C.U.G. I",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.133664410,
                "longitude": 27.575643420,
                "activeLineId": "5"
            },
            {
                "id": "1d6ebd96-f3a4-47ab-9b1f-08d7aca9d6cc",
                "name": "Bazar",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.134067360,
                "longitude": 27.580518200,
                "activeLineId": "5"
            },
            {
                "id": "c7097e9c-5598-4e70-9b20-08d7aca9d6cc",
                "name": "Blocuri Cetatuia",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.135413230,
                "longitude": 27.586502490,
                "activeLineId": "5"
            },
            {
                "id": "ffd40836-c686-45d3-9b21-08d7aca9d6cc",
                "name": "Liceul C.U.G.",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.136342960,
                "longitude": 27.593847660,
                "activeLineId": "5"
            },
            {
                "id": "66eca43b-c7a8-4d5c-9b22-08d7aca9d6cc",
                "name": "Continental",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.136825160,
                "longitude": 27.600370910,
                "activeLineId": "5"
            },
            {
                "id": "46a3f94f-f19e-47c4-9b23-08d7aca9d6cc",
                "name": "Camine C.U.G.",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.137100050,
                "longitude": 27.604811280,
                "activeLineId": "5"
            },
            {
                "id": "99960a43-1b42-4499-9b24-08d7aca9d6cc",
                "name": "Frigorifer",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.142051660,
                "longitude": 27.599338850,
                "activeLineId": "5"
            },
            {
                "id": "16b2d471-fa0c-4cc3-9b25-08d7aca9d6cc",
                "name": "Casa Sindicatelor",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.145278010,
                "longitude": 27.594761960,
                "activeLineId": "5"
            },
            {
                "id": "2ca9e1ea-1362-485d-9b26-08d7aca9d6cc",
                "name": "Tesatura",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.149652970,
                "longitude": 27.595154890,
                "activeLineId": "5"
            },
            {
                "id": "efab1948-b808-48b4-9b27-08d7aca9d6cc",
                "name": "Scoala Ion Ghica",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.152114360,
                "longitude": 27.598600170,
                "activeLineId": "5"
            },
            {
                "id": "dca24166-8921-4b25-9b28-08d7aca9d6cc",
                "name": "C.T.P. - Sectia nr. 1",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.153901445,
                "longitude": 27.602768540,
                "activeLineId": "5"
            },
            {
                "id": "ac39e797-8de6-4b55-9b29-08d7aca9d6cc",
                "name": "Tudor Vladimirescu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.156376720,
                "longitude": 27.603750500,
                "activeLineId": "5"
            },
            {
                "id": "332184ff-9243-4f0e-9b2a-08d7aca9d6cc",
                "name": "Bucsinescu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.158988400,
                "longitude": 27.600078610,
                "activeLineId": "5"
            },
            {
                "id": "8c8983e9-e0c5-4f6f-9b2b-08d7aca9d6cc",
                "name": "Elena Doamna",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161012890,
                "longitude": 27.596099230,
                "activeLineId": "5"
            },
            {
                "id": "b6f61730-d308-40b3-9b2c-08d7aca9d6cc",
                "name": "Targu Cucu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.165788859,
                "longitude": 27.589631081,
                "activeLineId": "5"
            },
            {
                "id": "789ee3fa-acc6-41cd-9b2d-08d7aca9d6cc",
                "name": "Piata Independentei",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.168471220,
                "longitude": 27.579577750,
                "activeLineId": "5"
            },
            {
                "id": "0647c657-ae57-4e3a-9b2e-08d7aca9d6cc",
                "name": "Universitate",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.175396580,
                "longitude": 27.571799960,
                "activeLineId": "5"
            },
            {
                "id": "6c2a68bd-4903-4cfe-9b2f-08d7aca9d6cc",
                "name": "Triumf",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.180836250,
                "longitude": 27.567291220,
                "activeLineId": "5"
            },
            {
                "id": "cc6811ee-2e00-4bb7-9b30-08d7aca9d6cc",
                "name": "George Cosbuc",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.183524530,
                "longitude": 27.564972740,
                "activeLineId": "5"
            },
            {
                "id": "323d6790-2f23-4a71-9b31-08d7aca9d6cc",
                "name": "Stadion",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.185660200,
                "longitude": 27.563137020,
                "activeLineId": "5"
            },
            {
                "id": "75fc7eda-05d9-47fc-9b32-08d7aca9d6cc",
                "name": "Copou",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.190838916,
                "longitude": 27.559069991,
                "activeLineId": "5"
            }
        ];
    }

    private get line43Details(): ActiveLine {
        return {
            id: "7",
            name: "43",
            userLatitude: 1,
            userLongitude: 1,
            activeStations: [],
            nextStation: "",
            nextStationStatus: "",
            timestamp: Date.now(),
            type: null
        }
    }
    private get line43Stations(): ActiveStation[] {
        return [
            {
                "id": "4e4bd43b-0651-4b95-9b33-08d7aca9d6cc",
                "name": "C.U.G. I",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.133664410,
                "longitude": 27.575643420,
                "activeLineId": "7"
            },
            {
                "id": "5f7ab5c9-2d69-4611-9b34-08d7aca9d6cc",
                "name": "Bazar",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.134067360,
                "longitude": 27.580518200,
                "activeLineId": "7"
            },
            {
                "id": "f0caae25-e3a4-4b69-9b35-08d7aca9d6cc",
                "name": "Blocuri Cetatuia",
                "isActive": false,
                "isPassed": true,
                "latitude": 47.135413230,
                "longitude": 27.586502490,
                "activeLineId": "7"
            },
            {
                "id": "7ae55287-fc86-4f14-9b36-08d7aca9d6cc",
                "name": "Liceul C.U.G.",
                "isActive": true,
                "isPassed": true,
                "latitude": 47.136342960,
                "longitude": 27.593847660,
                "activeLineId": "7"
            },
            {
                "id": "ac3bf679-c3a5-402f-9b37-08d7aca9d6cc",
                "name": "Continental",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.136825160,
                "longitude": 27.600370910,
                "activeLineId": "7"
            },
            {
                "id": "cf2d14a7-2f81-4923-9b38-08d7aca9d6cc",
                "name": "Camine C.U.G.",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.137100050,
                "longitude": 27.604811280,
                "activeLineId": "7"
            },
            {
                "id": "fd2e4383-3b5a-4bdc-9b39-08d7aca9d6cc",
                "name": "Frigorifer",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.142051660,
                "longitude": 27.599338850,
                "activeLineId": "7"
            },
            {
                "id": "c6b2ffa0-4d6f-4e4a-9b3a-08d7aca9d6cc",
                "name": "Casa Sindicatelor",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.145278010,
                "longitude": 27.594761960,
                "activeLineId": "7"
            },
            {
                "id": "1aef7dbf-7a95-49fa-9b3b-08d7aca9d6cc",
                "name": "Tesatura",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.149652970,
                "longitude": 27.595154890,
                "activeLineId": "7"
            },
            {
                "id": "a497c701-c9a9-420a-9b3c-08d7aca9d6cc",
                "name": "Scoala Ion Ghica",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.152114360,
                "longitude": 27.598600170,
                "activeLineId": "7"
            },
            {
                "id": "7c161592-d8d5-4ec0-9b3d-08d7aca9d6cc",
                "name": "C.T.P. - Sectia nr. 1",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.153839580,
                "longitude": 27.602698390,
                "activeLineId": "7"
            },
            {
                "id": "cdf6ce3f-1802-4ee2-9b3e-08d7aca9d6cc",
                "name": "Tudor Vladimirescu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.156376720,
                "longitude": 27.603750500,
                "activeLineId": "7"
            },
            {
                "id": "da5a6c9b-7dff-48a3-9b3f-08d7aca9d6cc",
                "name": "Bucsinescu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.158988400,
                "longitude": 27.600078610,
                "activeLineId": "7"
            },
            {
                "id": "e551d26b-fafa-4db6-9b40-08d7aca9d6cc",
                "name": "Elena Doamna",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.161012890,
                "longitude": 27.596099230,
                "activeLineId": "7"
            },
            {
                "id": "e72b2f28-447e-49d1-9b41-08d7aca9d6cc",
                "name": "Targu Cucu",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.165731130,
                "longitude": 27.589794580,
                "activeLineId": "7"
            },
            {
                "id": "24dc76b2-fd10-4388-9b42-08d7aca9d6cc",
                "name": "Piata Independentei",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.168471220,
                "longitude": 27.579577750,
                "activeLineId": "7"
            },
            {
                "id": "f51e52ea-e274-48d5-9b43-08d7aca9d6cc",
                "name": "Blocuri Pacurari",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.170880420,
                "longitude": 27.571197300,
                "activeLineId": "7"
            },
            {
                "id": "6eb28c02-12a5-48a7-9b44-08d7aca9d6cc",
                "name": "Petru Poni",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.173634000,
                "longitude": 27.559088860,
                "activeLineId": "7"
            },
            {
                "id": "17852e95-c5a9-4ea2-9b45-08d7aca9d6cc",
                "name": "Moara 1 Mai",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.174527370,
                "longitude": 27.550455480,
                "activeLineId": "7"
            },
            {
                "id": "76200aaf-0098-437c-9b46-08d7aca9d6cc",
                "name": "Cimitirul Evreiesc",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.174798090,
                "longitude": 27.544137610,
                "activeLineId": "7"
            },
            {
                "id": "16888cc7-019c-4145-9b47-08d7aca9d6cc",
                "name": "OMV Pacurari",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.173524930,
                "longitude": 27.537375390,
                "activeLineId": "7"
            },
            {
                "id": "85039f01-4b27-4f0e-9b48-08d7aca9d6cc",
                "name": "Pacurari",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.173083380,
                "longitude": 27.533709440,
                "activeLineId": "7"
            },
            {
                "id": "5d820814-fabb-491d-9b49-08d7aca9d6cc",
                "name": "Pacurari",
                "isActive": false,
                "isPassed": false,
                "latitude": 47.172888410,
                "longitude": 27.533108470,
                "activeLineId": "7"
            }
        ]
    }
}