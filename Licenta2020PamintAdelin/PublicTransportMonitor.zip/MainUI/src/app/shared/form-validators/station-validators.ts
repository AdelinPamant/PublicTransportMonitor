import { AbstractControl, ValidatorFn } from '@angular/forms';

export class StationValidators {

    constructor(
        
    ) { }

    // static isStation(station: string): ValidatorFn {
    //     return (abstractControl: AbstractControl): { [key: string]: boolean } | null => {
    //         if (abstractControl.value === null)
    //     }
    // }
}