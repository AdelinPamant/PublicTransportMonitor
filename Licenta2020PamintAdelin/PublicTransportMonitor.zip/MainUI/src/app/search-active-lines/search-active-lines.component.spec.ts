import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchActiveLinesComponent } from './search-active-lines.component';

describe('SearchActiveLinesComponent', () => {
  let component: SearchActiveLinesComponent;
  let fixture: ComponentFixture<SearchActiveLinesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchActiveLinesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchActiveLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
