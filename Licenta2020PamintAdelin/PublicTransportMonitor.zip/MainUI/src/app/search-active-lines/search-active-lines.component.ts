import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { combineLatest } from 'rxjs';
import { Router } from '@angular/router';

import { ActiveLineService, StationService } from '../api/services';
import { ActiveLine, Station } from '../api/models';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-search-active-lines',
  templateUrl: './search-active-lines.component.html',
  styleUrls: ['./search-active-lines.component.scss']
})
export class SearchActiveLinesComponent implements OnInit {

  protected stationsForm: FormGroup;
  protected activeLines: ActiveLine[];
  protected startFilteredStations: string[]
  protected destinationFilteredStations: string[];

  constructor(
    private readonly _fb: FormBuilder,
    private readonly _router: Router,
    private readonly _activeLineService: ActiveLineService,
    private readonly _stationService: StationService
  ) { }

  public ngOnInit() {
    this.stationsForm = this._fb.group({
      startStation: [''],
      destinationStation: ['']
    });

    this.handleStationAutocomplete();
  }

  protected submit() {
    this.getActiveLines();

    this._activeLineService.refreshDataFromFunc(this.getActiveLines);
  }

  protected openLineDetails(id: number): void {
    this._router.navigate(['/active-line-details', id]);
  }

  private getActiveLines(): void {
    this._activeLineService.getActiveLines(
      this.stationsForm.get('startStation').value,
      this.stationsForm.get('destinationStation').value
    ).subscribe(
      (data: ActiveLine[]) => this.activeLines = data
    );
  }

  private handleStationAutocomplete(): void {
    combineLatest([
      this._stationService.getStations(),
      this.stationsForm.valueChanges
    ])
    .subscribe(
      ([stations, formData]) => {
        this.startFilteredStations = this.filter(formData.startStation, stations),
        this.destinationFilteredStations = this.filter(formData.destinationStation, stations)
      }
    );
  }

  private filter(value: string, stations: Station[]): string[] {
    const filterValue = value.toLocaleLowerCase();

    return stations.filter(station => station.name.toLocaleLowerCase().includes(filterValue)).map(station => station.name);
  }
}
