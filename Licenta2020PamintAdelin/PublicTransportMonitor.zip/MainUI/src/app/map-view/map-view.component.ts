import { Component, OnInit } from '@angular/core';

import { ActiveLine } from '../api/models';
import { ActiveLineService } from '../api/services';
import { ArrayHelperService } from '../shared/services/array-helper.service';
import { MockLocationService } from '../shared/services/mock-location.service';

@Component({
  selector: 'app-map-view',
  templateUrl: './map-view.component.html',
  styleUrls: ['./map-view.component.scss']
})
export class MapViewComponent implements OnInit {

  private _filterInfo: string;
  protected get filterInfo() {
    return this._filterInfo;
  }
  protected set filterInfo(value: string) {
    this._filterInfo = value;
    this.activeLines = this.getFilteredActiveLines(this.activeLines, value);
    this.activeLinesCopy = this.getFilteredActiveLines(this.activeLines, value);
  }
  protected activeLines: ActiveLine[];
  private activeLinesCopy: ActiveLine[];

  constructor(
    private readonly _activeLineService: ActiveLineService,
    private readonly _mockLocationService: MockLocationService,
    private readonly _arrayHelperService: ArrayHelperService<ActiveLine>) {

    // this._activeLineService.refreshDataFromFunc(() => {
    //   this._activeLineService.getAllActiveLines().subscribe(
    //     (activeLines: ActiveLine[]) => {
    //       if (!_arrayHelperService.areArraysTheSame(activeLines, this.activeLinesCopy)) {
    //         this.activeLines = this.getFilteredActiveLines(activeLines, this._filterInfo);
    //         this.activeLinesCopy = this.activeLines;
    //       }
    //     });
    // });
  }

  ngOnInit() {
    // this._activeLineService.getAllActiveLines().subscribe(
    //   (activeLines: ActiveLine[]) => {
    //     this.activeLines = activeLines;
    //     this.activeLinesCopy = activeLines;
    //   });

    this._mockLocationService.mockReadLocation$.subscribe(
      (activeLines: ActiveLine[]) => {
        this.activeLines = this.getFilteredActiveLines(activeLines, this._filterInfo);
      }
    );
  }

  private getFilteredActiveLines(activeLines: ActiveLine[], filter: string): ActiveLine[] {
    if (filter === '' || filter === undefined) return activeLines;

    return activeLines.filter(activeLine => activeLine.name.includes(filter));
  }
}
