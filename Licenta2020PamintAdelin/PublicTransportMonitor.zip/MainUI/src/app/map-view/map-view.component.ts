import { Component, OnInit } from '@angular/core';

import { ActiveLine } from '../api/models';
import { ActiveLineService } from '../api/services';
import { ArrayHelperService } from '../shared/services/array-helper.service';

@Component({
  selector: 'app-map-view',
  templateUrl: './map-view.component.html',
  styleUrls: ['./map-view.component.scss']
})
export class MapViewComponent implements OnInit {

  protected activeLines: ActiveLine[];
  private activeLinesCopy: ActiveLine[];

  constructor(
    private readonly _activeLineService: ActiveLineService,
    private readonly _arrayHelperService: ArrayHelperService<ActiveLine>) {

    this._activeLineService.refreshDataFromFunc(() => {
      this._activeLineService.getAllActiveLines().subscribe(
        (activeLines: ActiveLine[]) => {
          if (!_arrayHelperService.areArraysTheSame(activeLines, this.activeLinesCopy)) {
            this.activeLines = activeLines;
            this.activeLinesCopy = activeLines;
          }
        });
    });
  }

  ngOnInit() {
    this._activeLineService.getAllActiveLines().subscribe(
      (activeLines: ActiveLine[]) => {
        this.activeLines = activeLines;
        this.activeLinesCopy = activeLines;
      });
  }
}
