import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Station } from '../models';

@Injectable({
  providedIn: 'root'
})
export class StationService {
  
  private _baseStationUrl = environment.api + 'stations/';

  constructor(private readonly _http: HttpClient) { }

  public getStations(): Observable<Station[]> {
    return this._http.get<Station[]>(this._baseStationUrl);
  }
}
