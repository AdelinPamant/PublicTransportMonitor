import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { Line } from '../models';

@Injectable({
  providedIn: 'root'
})
export class LineService {

  private _baseLineUrl = environment.api + 'lines';

  constructor(private readonly _http: HttpClient) { }

  public getLines(): Observable<Line[]> {
    return this._http.get<Line[]>(this._baseLineUrl);
  }
}
