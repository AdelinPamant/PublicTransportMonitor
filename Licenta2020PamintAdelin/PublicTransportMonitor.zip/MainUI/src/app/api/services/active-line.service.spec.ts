import { TestBed } from '@angular/core/testing';

import { ActiveLineService } from './active-line.service';

describe('ActiveLineService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActiveLineService = TestBed.get(ActiveLineService);
    expect(service).toBeTruthy();
  });
});
