import { TestBed } from '@angular/core/testing';

import { ActiveStationService } from './active-station.service';

describe('ActiveStationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActiveStationService = TestBed.get(ActiveStationService);
    expect(service).toBeTruthy();
  });
});
