import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ActiveStation } from '../models';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ActiveStationService {

  private _baseActiveStationUrl = environment.api + 'activeStations/'

  constructor(private readonly _http: HttpClient) { }

  public getActiveStationsForActiveLineId(activeLineId: string): Observable<ActiveStation[]> {
    const stationsForActiveLineUri = this._baseActiveStationUrl + activeLineId;

    return this._http.get<ActiveStation[]>(stationsForActiveLineUri);
  }
}
