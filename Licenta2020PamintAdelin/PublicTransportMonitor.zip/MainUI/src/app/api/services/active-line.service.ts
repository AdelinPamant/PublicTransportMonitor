import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, of, iif, Subject, interval, Subscription } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { ActiveLineForCreation, ActiveLine, ActiveLineForPatch } from '../models';

const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

@Injectable({
  providedIn: 'root'
})
export class ActiveLineService {
  private _baseActiveLineUrl = environment.api + 'activeLines/';
  private _activeLineUpdatedSource = new Subject<void>();

  public activeLineUpdated$ = this._activeLineUpdatedSource.asObservable();

  constructor(private readonly _http: HttpClient) { }

  public refreshDataFromFunc(func: () => void): Subscription {
    return interval(2000).subscribe(() => {
      func();
    });
  }

  public alertActiveLineUpdate(): void {
    this._activeLineUpdatedSource.next();
  }

  public getAllActiveLines(): Observable<ActiveLine[]> {
    return this._http.get<ActiveLine[]>(
      this._baseActiveLineUrl,
      {
        params: {
          startStation: '',
          destinationStation: ''
        }
      });
  }

  public getActiveLines(
    startStation: string,
    destinationStation: string): Observable<ActiveLine[]> {
      return this._http.get<ActiveLine[]>(
        this._baseActiveLineUrl,
        {
          params: {
            startStation: startStation,
            destinationStation: destinationStation
          }
        });
  }

  public getActiveLineById(id: string): Observable<ActiveLine> {
    const activeLineUri = this._baseActiveLineUrl + id;

    return this._http.get<ActiveLine>(activeLineUri);
  }

  public getActiveLineObservableByUri(
    activeLineUri: string,
    activeLineForCreation: ActiveLineForCreation,
    activeLineForPatch: ActiveLineForPatch): Observable<HttpResponse<ActiveLineForCreation> | ActiveLine> {
      return of(activeLineUri)
        .pipe(
          mergeMap(uri => 
            iif(() => uri === '',
              this.registerActiveLine(
                activeLineForCreation),
              this.patchActiveLine(
                activeLineUri,
                activeLineForPatch))
          )
        );
  }

  public registerActiveLine(activeLine: ActiveLineForCreation): Observable<HttpResponse<ActiveLineForCreation>> {
    return this._http.post<ActiveLineForCreation>(
      this._baseActiveLineUrl,
      activeLine,
      { 
        headers: headers,
        observe: 'response'
      });
  }

  public patchActiveLine(
    uri: string, 
    activeLineForPatch: ActiveLineForPatch): Observable<ActiveLine> {
      return this._http.patch<ActiveLine>(
        uri,
        [
          {
            "op": "replace",
            "path": "/userLatitude",
            "value": activeLineForPatch.userLatitude
          },
          {
            "op": "replace",
            "path": "/userLongitude",
            "value": activeLineForPatch.userLongitude
          }
        ]);
  }

  deleteActiveLineById(activeLineId: string): Observable<{}> {
    const activeLineUri = this._baseActiveLineUrl + activeLineId;

    return this._http.delete(
      activeLineUri,
      {
        headers: headers
      });
  }
}
