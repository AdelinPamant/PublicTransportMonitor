export class ActiveLineForCreation { 
    name: string;
    startStation: string;
    destinationStation: string; 
    userLatitude: number;
    userLongitude: number;
    timestamp: number;
}