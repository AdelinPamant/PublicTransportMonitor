import { ActiveLine } from './active-line';

export class ActiveStation {
    id: string;
    name: string;
    isActive: boolean;
    isPassed: boolean;
    latitude: number;
    longitude: number;
    // activeLine: ActiveLine;
    activeLineId: string;
}