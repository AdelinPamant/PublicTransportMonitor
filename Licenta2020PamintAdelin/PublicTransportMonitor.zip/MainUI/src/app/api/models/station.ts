export class Station {
    name: string;
}