import { ActiveStation } from './active-station';

export class ActiveLine {
    id: string;
    name: string;
    activeStations: ActiveStation[];
    userLatitude: number;
    userLongitude: number;
    type: string;
    nextStation: string;
    nextStationStatus: string;
    timestamp: number;
}