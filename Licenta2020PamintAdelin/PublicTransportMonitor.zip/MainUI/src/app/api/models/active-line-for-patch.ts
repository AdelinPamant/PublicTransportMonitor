export class ActiveLineForPatch {
    userLatitude: number;
    userLongitude: number;
    timestamp: number;
}