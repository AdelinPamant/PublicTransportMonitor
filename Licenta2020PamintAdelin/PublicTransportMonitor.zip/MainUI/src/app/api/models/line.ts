export class Line {
    name: string;
}