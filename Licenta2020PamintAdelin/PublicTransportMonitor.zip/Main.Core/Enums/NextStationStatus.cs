﻿namespace Main.Core.Enums
{
    public enum NextStationStatus
    {
        WithinStationRange,
        InStation,
        JustLeftStation
    }
}