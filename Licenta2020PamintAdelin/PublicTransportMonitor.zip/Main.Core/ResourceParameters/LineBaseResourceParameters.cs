﻿namespace Main.Core.ResourceParameters
{
    public class LineBaseResourceParameters
    {
        public string StartStation { get; set; }

        public string DestinationStation { get; set; }
    }
}
