﻿namespace Main.Core.ResourceParameters
{
    public class LineResourceParameters : LineBaseResourceParameters
    {
    }
}
