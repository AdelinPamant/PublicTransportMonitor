﻿namespace Main.Core.ResourceParameters
{
    public class ActiveLineResourceParameters : LineBaseResourceParameters
    {
    }
}
