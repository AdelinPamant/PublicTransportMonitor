﻿namespace Main.Core.RepositoryInterfaces
{
    public interface IRepositoryBase
    {
        void SaveChanges();
    }
}