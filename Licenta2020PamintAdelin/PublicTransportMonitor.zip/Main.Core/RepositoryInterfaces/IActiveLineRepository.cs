﻿using System;
using System.Collections.Generic;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Main.Core.RepositoryInterfaces
{
    public interface IActiveLineRepository : IRepositoryBase
    {
        IEnumerable<ActiveLine> GetActiveLines(ActiveLineResourceParameters activeLineResourceParameters);
        IEnumerable<ActiveLine> GetActiveLines();
        void AddActiveLine(ActiveLine activeLine);
        void UpdateActiveLine(ActiveLine activeLine);
        void DeleteActiveLine(Guid activeLineId);
    }
}
