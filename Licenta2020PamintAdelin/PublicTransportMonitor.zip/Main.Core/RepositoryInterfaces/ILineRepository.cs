﻿using System.Collections.Generic;
using Main.Core.Entities;
using Main.Core.ResourceParameters;

namespace Main.Core.RepositoryInterfaces
{
    public interface ILineRepository : IRepositoryBase
    {
        IEnumerable<Line> GetLines(LineResourceParameters lineResourceParameters);
        IEnumerable<Line> GetLines();
    }
}
