﻿using System.Collections.Generic;
using Main.Core.Entities;

namespace Main.Core.RepositoryInterfaces
{
    public interface IActiveStationRepository : IRepositoryBase
    {
        IEnumerable<ActiveStation> GetActiveStations();
    }
}