﻿using System.Collections.Generic;
using Main.Core.Entities;

namespace Main.Core.RepositoryInterfaces
{
    public interface IStationRepository : IRepositoryBase
    {
        IEnumerable<Station> GetAllStations();
    }
}