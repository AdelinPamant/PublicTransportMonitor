﻿using System;
using System.Collections.Generic;
using Main.Core.StaticData;

namespace Main.Core.Entities
{
    public class Route
    {
        public Route()
        {
            Stations = new List<Station>();
        }

        public Guid Id { get; set; }

        public string Type { get; set; }

        public List<Station> Stations { get; set; }

        public Line Line { get; set; }

        public Guid LineId { get; set; }

        public static Route CreateStartToFinishRoute(List<Station> stations)
        {
            return new Route
            {
                Type = RouteStaticData.StartToFinish,
                Stations = stations
            };
        }

        public static Route CreateFinishToStartRoute(List<Station> stations)
        {
            return new Route
            {
                Type = RouteStaticData.FinishToStart,
                Stations = stations
            };
        }
    }
}
