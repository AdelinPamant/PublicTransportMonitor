﻿using System;

namespace Main.Core.Entities
{
    public class Station
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public decimal Latitude { get; set; }

        public decimal Longitude { get; set; }

        public Route Route { get; set; }

        public Guid RouteId { get; set; }

        public override bool Equals(object obj)
        {
            var item = obj as Station;

            return
                Name == item.Name
                && Latitude == item.Latitude
                && Longitude == item.Longitude;
        }
    }
}
