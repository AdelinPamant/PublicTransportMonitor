﻿using System;
using System.Collections.Generic;
using Main.Core.Enums;

namespace Main.Core.Entities
{
    public class ActiveLine
    {
        public ActiveLine()
        {
            ActiveStations = new List<ActiveStation>();
        }

        public Guid Id { get; set; }

        public string Name { get; set; }

        public decimal UserLatitude { get; set; }

        public decimal UserLongitude { get; set; }

        public string NextStation { get; set; }

        public NextStationStatus NextStationStatus { get; set; }

        public long Timestamp { get; set; }

        public List<ActiveStation> ActiveStations { get; set; }

        public string Type { get; set; }
    }
}
