﻿namespace Main.Core.StaticData
{
    public static class RouteStaticData
    {
        public static string StartToFinish => nameof(StartToFinish);
        public static string FinishToStart => nameof(FinishToStart);
    }
}