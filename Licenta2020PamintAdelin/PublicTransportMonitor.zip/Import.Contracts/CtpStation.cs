﻿namespace Import.Contracts
{
    public class CtpStation
    {
        public string _id { get; set; }

        public int StationId { get; set; }

        public string Name { get; set; }

        public int Distance { get; set; }

        public int Important { get; set; }

        public int Index { get; set; }

        public int Index_station { get; set; }

        public decimal Lat { get; set; }

        public decimal Lng { get; set; }

        public int Total { get; set; }
    }
}
