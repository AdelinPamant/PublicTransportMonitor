﻿namespace Import.Contracts
{
    public class CtpRoute
    {
        public CtpLine Data { get; set; }

        public bool Type { get; set; }
    }
}
