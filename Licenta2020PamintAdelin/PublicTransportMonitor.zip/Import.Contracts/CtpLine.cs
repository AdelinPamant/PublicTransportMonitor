﻿using System.Collections.Generic;

namespace Import.Contracts
{
    public class CtpLine
    {
        public string _id { get; set; }

        public string RouteColor { get; set; }

        public string RouteDescription { get; set; }

        public int RouteId { get; set; }

        public string RouteName { get; set; }

        public List<CtpCoordinateDetails> RouteRoundWayCoordinates { get; set; }

        public string RouteRoundWayLength { get; set; }

        public List<CtpStation> RouteRoundWaypoints { get; set; }

        public string RouteShortName { get; set; }

        public int RouteStatus { get; set; }

        public string RouteType { get; set; }

        public List<CtpCoordinateDetails> RouteWayCoordinates { get; set; }

        public string RouteWayLength { get; set; }

        public string RouteWayType { get; set; }

        public List<CtpStation> RouteWaypoints { get; set; }

        public int __v { get; set; }
    }
}
