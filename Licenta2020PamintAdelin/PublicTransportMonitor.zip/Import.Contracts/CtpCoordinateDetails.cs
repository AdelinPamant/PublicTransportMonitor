﻿namespace Import.Contracts
{
    public class CtpCoordinateDetails
    {
        public string _id { get; set; }

        public decimal Lat { get; set; }

        public decimal Lng { get; set; }
    }
}
